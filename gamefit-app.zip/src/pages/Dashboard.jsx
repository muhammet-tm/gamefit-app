import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Trophy, 
  Zap, 
  Target, 
  TrendingUp, 
  Flame,
  Calendar,
  Award,
  ChevronRight,
  BarChart3,
  PieChart
} from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek } from "date-fns";

import StatsCard from "../components/dashboard/StatsCard";
import RecentWorkouts from "../components/dashboard/RecentWorkouts";
import AvatarDisplay from "../components/dashboard/AvatarDisplay";
import QuickActions from "../components/dashboard/QuickActions";
import WorkoutChart from "../components/analytics/WorkoutChart";
import WorkoutTypeDistribution from "../components/analytics/WorkoutTypeDistribution";
import StreakCalendar from "../components/analytics/StreakCalendar";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [chartPeriod, setChartPeriod] = useState("week"); // week, month

  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      return currentUser;
    }
  });

  const { data: workouts, isLoading: workoutsLoading } = useQuery({
    queryKey: ['recentWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: userData?.email }, '-created_date', 5),
    enabled: !!userData,
    initialData: []
  });

  const { data: allWorkouts } = useQuery({
    queryKey: ['allUserWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: userData?.email }),
    enabled: !!userData,
    initialData: []
  });

  const xpToNextLevel = () => {
    if (!user) return 0;
    const currentLevel = user.level || 1;
    const requiredXP = Math.floor(100 * Math.pow(1.5, currentLevel - 1));
    const currentXP = user.total_xp || 0;
    const levelStartXP = currentLevel > 1 ? Math.floor(100 * Math.pow(1.5, currentLevel - 2)) : 0;
    const progress = ((currentXP - levelStartXP) / (requiredXP - levelStartXP)) * 100;
    return Math.min(progress, 100);
  };

  // Analytics Data Processing
  const getWeeklyXPData = () => {
    const data = [];
    const days = chartPeriod === "week" ? 7 : 30;
    
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayWorkouts = allWorkouts.filter(w => {
        const workoutDate = new Date(w.created_date);
        return format(workoutDate, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd');
      });
      
      const totalXP = dayWorkouts.reduce((sum, w) => sum + (w.xp_earned || 0), 0);
      
      data.push({
        name: format(date, chartPeriod === "week" ? 'EEE' : 'MMM d'),
        value: totalXP
      });
    }
    return data;
  };

  const getWorkoutTypeDist = () => {
    const typeCount = {};
    allWorkouts.forEach(w => {
      typeCount[w.exercise_type] = (typeCount[w.exercise_type] || 0) + 1;
    });
    
    return Object.entries(typeCount)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);
  };

  const getWorkoutDates = () => {
    return allWorkouts.map(w => w.created_date);
  };

  const thisWeekWorkouts = allWorkouts?.filter(w => {
    const workoutDate = new Date(w.created_date);
    const weekStart = startOfWeek(new Date());
    const weekEnd = endOfWeek(new Date());
    return workoutDate >= weekStart && workoutDate <= weekEnd;
  }).length || 0;

  const totalXPThisWeek = allWorkouts?.filter(w => {
    const workoutDate = new Date(w.created_date);
    const weekStart = startOfWeek(new Date());
    const weekEnd = endOfWeek(new Date());
    return workoutDate >= weekStart && workoutDate <= weekEnd;
  }).reduce((sum, w) => sum + (w.xp_earned || 0), 0) || 0;

  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="neuro-card p-8">
          <p className="text-lg">Loading your fitness journey...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="neuro-card p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, <span className="text-gradient">{user?.full_name || 'Warrior'}!</span>
            </h1>
            <p style={{ color: 'var(--text-secondary)' }} className="mb-4">
              Ready to level up today? You're on fire! 🔥
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-semibold flex items-center gap-2">
                  <Trophy className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
                  Level {user?.level || 1}
                </span>
                <span style={{ color: 'var(--text-secondary)' }}>
                  {user?.total_xp || 0} XP
                </span>
              </div>
              <div className="neuro-card-inset rounded-full h-4 overflow-hidden">
                <div 
                  className="h-full transition-all duration-500"
                  style={{ 
                    width: `${xpToNextLevel()}%`,
                    background: 'linear-gradient(90deg, var(--accent-red), var(--accent-yellow))'
                  }}
                />
              </div>
            </div>
          </div>

          <AvatarDisplay user={user} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard icon={Zap} label="Total XP" value={user?.total_xp || 0} color="var(--accent-yellow)" />
        <StatsCard icon={Flame} label="Current Streak" value={`${user?.current_streak || 0} days`} color="var(--accent-red)" />
        <StatsCard icon={Calendar} label="This Week" value={`${thisWeekWorkouts} workouts`} color="#4ade80" />
        <StatsCard icon={Award} label="GameFit Coins" value={user?.coins || 0} color="var(--accent-yellow)" />
      </div>

      <QuickActions />

      {/* Analytics Section */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* XP Progress Chart */}
        <div className="neuro-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
              <h3 className="font-semibold">XP Progress</h3>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setChartPeriod("week")}
                className={`neuro-button px-3 py-1 text-sm ${chartPeriod === "week" ? 'nav-item-active' : ''}`}
              >
                Week
              </button>
              <button
                onClick={() => setChartPeriod("month")}
                className={`neuro-button px-3 py-1 text-sm ${chartPeriod === "month" ? 'nav-item-active' : ''}`}
              >
                Month
              </button>
            </div>
          </div>
          <WorkoutChart data={getWeeklyXPData()} type="xp" />
        </div>

        {/* Workout Type Distribution */}
        <div className="neuro-card p-6">
          <div className="flex items-center gap-2 mb-4">
            <PieChart className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
            <h3 className="font-semibold">Workout Types</h3>
          </div>
          {getWorkoutTypeDist().length > 0 ? (
            <WorkoutTypeDistribution data={getWorkoutTypeDist()} />
          ) : (
            <div className="h-[300px] flex items-center justify-center">
              <p style={{ color: 'var(--text-secondary)' }} className="text-sm">
                No workout data yet. Start logging workouts!
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Streak Calendar */}
      <div className="neuro-card p-6">
        <StreakCalendar workoutDates={getWorkoutDates()} />
      </div>

      <RecentWorkouts workouts={workouts} isLoading={workoutsLoading} />

      {user?.fitness_goal && (
        <div className="neuro-card p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
                <h3 className="font-semibold text-lg">Your Fitness Goal</h3>
              </div>
              <p className="text-2xl font-bold text-gradient mb-2">{user.fitness_goal}</p>
              <p style={{ color: 'var(--text-secondary)' }} className="text-sm">
                Keep pushing! You've earned {totalXPThisWeek} XP this week.
              </p>
            </div>
            <Link to={createPageUrl("Profile")} className="neuro-button p-3">
              <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}