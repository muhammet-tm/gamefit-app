
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Dumbbell, 
  Clock, 
  Zap, 
  CheckCircle,
  Play,
  Pause,
  Square,
  AlertCircle
} from "lucide-react";

import GameFitLogo from "../components/shared/GameFitLogo";

export default function WorkoutLog() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState("setup"); // setup, timer, complete
  const [formData, setFormData] = useState({
    exercise_type: "Running",
    body_part: "Cardio",
    duration: 0,
    intensity: "Moderate",
    notes: ""
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [timerStarted, setTimerStarted] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  // Timer countdown
  useEffect(() => {
    let interval;
    if (timerRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setTimerRunning(false);
            setStep("complete");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerRunning, timeRemaining]);

  const durationOptions = [
    { label: "15 min", value: 15 },
    { label: "30 min", value: 30 },
    { label: "45 min", value: 45 },
    { label: "1 hour", value: 60 },
    { label: "1.5 hours", value: 90 },
    { label: "2 hours", value: 120 }
  ];

  const exerciseTypes = [
    "Running", "Weightlifting", "Yoga", "Cycling", "Swimming", 
    "HIIT", "Walking", "Stretching", "Sports", "Other"
  ];

  const bodyParts = ["Upper Body", "Lower Body", "Core", "Full Body", "Cardio"];
  const intensityLevels = ["Light", "Moderate", "Intense"];

  const calculateXP = (duration, intensity) => {
    const intensityMultipliers = { Light: 1, Moderate: 1.5, Intense: 2 };
    const baseXP = parseInt(duration) || 0;
    return Math.floor(baseXP * intensityMultipliers[intensity]);
  };

  const calculateCalories = (duration, intensity) => {
    const intensityCalories = { Light: 4, Moderate: 6, Intense: 10 };
    return Math.floor((parseInt(duration) || 0) * intensityCalories[intensity]);
  };

  const startTimer = () => {
    if (formData.duration === 0) {
      alert("Please select a workout duration first");
      return;
    }
    setTimeRemaining(formData.duration * 60); // Convert to seconds
    setTimerRunning(true);
    setTimerStarted(true);
    setStep("timer");
  };

  const toggleTimer = () => {
    setTimerRunning(!timerRunning);
  };

  const stopTimer = () => {
    if (window.confirm("Are you sure you want to stop? Your workout won't be logged.")) {
      setTimerRunning(false);
      setTimeRemaining(0);
      setTimerStarted(false);
      setStep("setup");
    }
  };

  const logWorkoutMutation = useMutation({
    mutationFn: async (workoutData) => {
      const xpEarned = calculateXP(workoutData.duration, workoutData.intensity);
      const caloriesBurned = calculateCalories(workoutData.duration, workoutData.intensity);

      const workout = await base44.entities.Workout.create({
        ...workoutData,
        xp_earned: xpEarned,
        calories_burned: caloriesBurned
      });

      const newTotalXP = (user.total_xp || 0) + xpEarned;
      const newLevel = Math.floor(Math.log(newTotalXP / 100 + 1) / Math.log(1.5)) + 1;
      const newCoins = (user.coins || 0) + Math.floor(xpEarned / 10);

      const lastWorkoutDate = await base44.entities.Workout.filter(
        { created_by: user.email }, 
        '-created_date', 
        2
      );
      let currentStreak = user.current_streak || 0;
      if (lastWorkoutDate.length > 1) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        yesterday.setHours(0, 0, 0, 0);
        const lastDate = new Date(lastWorkoutDate[1].created_date);
        lastDate.setHours(0, 0, 0, 0);
        if (lastDate >= yesterday) {
          currentStreak += 1;
        } else {
          currentStreak = 1;
        }
      } else {
        currentStreak = 1;
      }

      await base44.auth.updateMe({
        total_xp: newTotalXP,
        level: newLevel,
        coins: newCoins,
        current_streak: currentStreak,
        best_streak: Math.max(currentStreak, user.best_streak || 0),
        last_workout_time: new Date().toISOString()
      });

      return { workout, xpEarned, newLevel, leveledUp: newLevel > (user.level || 1) };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries(['currentUser']);
      queryClient.invalidateQueries(['recentWorkouts']);
      queryClient.invalidateQueries(['allUserWorkouts']);
      setShowSuccess(true);
      
      setTimeout(() => {
        if (data.leveledUp) {
          alert(`🎉 LEVEL UP! You've reached Level ${data.newLevel}! Your avatar has evolved!`);
        }
        navigate(createPageUrl("Dashboard"));
      }, 1500);
    },
    onError: (error) => {
      alert(error.message || "Failed to log workout. Please try again.");
    }
  });

  const handleLogWorkout = () => {
    if (formData.exercise_type === "Sports" && !formData.body_part) {
      alert("Please select a body part for sports workout");
      return;
    }
    logWorkoutMutation.mutate(formData);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgressPercentage = () => {
    if (formData.duration === 0) return 0;
    return ((formData.duration * 60 - timeRemaining) / (formData.duration * 60)) * 100;
  };

  if (showSuccess) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="neuro-card p-12 text-center max-w-md">
          <CheckCircle className="w-20 h-20 mx-auto mb-4" style={{ color: '#4ade80' }} />
          <h2 className="text-2xl font-bold mb-2">Workout Logged!</h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Great job! +{logWorkoutMutation.data?.xpEarned} XP earned 🔥
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="neuro-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="neuro-card p-3">
            <Dumbbell className="w-6 h-6" style={{ color: 'var(--accent-red)' }} />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Log Your Workout</h1>
            <p style={{ color: 'var(--text-secondary)' }} className="text-sm">
              Complete the timer to earn XP
            </p>
          </div>
        </div>

        {step === "setup" && (
          <div className="space-y-6">
            {/* Exercise Type */}
            <div>
              <label className="block text-sm font-semibold mb-2">Exercise Type</label>
              <div className="neuro-card-inset p-1 rounded-xl">
                <select
                  value={formData.exercise_type}
                  onChange={(e) => setFormData({ ...formData, exercise_type: e.target.value })}
                  className="w-full px-4 py-3 bg-transparent outline-none"
                >
                  {exerciseTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>

            {formData.exercise_type === "Sports" && (
              <div>
                <label className="block text-sm font-semibold mb-2">Body Part Targeted</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {bodyParts.map((part) => (
                    <button
                      key={part}
                      type="button"
                      onClick={() => setFormData({ ...formData, body_part: part })}
                      className={`neuro-button p-3 text-center transition-all ${
                        formData.body_part === part ? 'nav-item-active' : ''
                      }`}
                    >
                      <p className="text-sm font-semibold">{part}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Duration Selection */}
            <div>
              <label className="block text-sm font-semibold mb-3">Set Workout Duration</label>
              <div className="grid grid-cols-3 gap-3">
                {durationOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, duration: option.value })}
                    className={`neuro-button p-6 text-center transition-all ${
                      formData.duration === option.value ? 'nav-item-active' : ''
                    }`}
                  >
                    <p className="text-2xl font-bold mb-1">{option.label.split(' ')[0]}</p>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                      {option.label.split(' ')[1]}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Intensity */}
            <div>
              <label className="block text-sm font-semibold mb-2">Intensity Level</label>
              <div className="grid grid-cols-3 gap-3">
                {intensityLevels.map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setFormData({ ...formData, intensity: level })}
                    className={`neuro-button p-4 text-center transition-all ${
                      formData.intensity === level ? 'nav-item-active' : ''
                    }`}
                  >
                    <p className="font-semibold">{level}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-semibold mb-2">Notes (optional)</label>
              <div className="neuro-card-inset p-4 rounded-xl">
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="How did it feel? Any achievements?"
                  rows="3"
                  className="w-full bg-transparent outline-none resize-none"
                />
              </div>
            </div>

            {/* Start Button */}
            <button
              onClick={startTimer}
              disabled={formData.duration === 0}
              className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2"
              style={formData.duration === 0 ? { opacity: 0.5, cursor: 'not-allowed' } : {}}
            >
              <Play className="w-5 h-5" />
              Start Workout Timer
            </button>
          </div>
        )}

        {step === "timer" && (
          <div className="space-y-8">
            {/* Timer Display */}
            <div className="flex flex-col items-center justify-center py-12">
              <div className="relative w-64 h-64 flex items-center justify-center">
                {/* Progress Circle */}
                <svg className="absolute w-full h-full transform -rotate-90">
                  <circle
                    cx="128"
                    cy="128"
                    r="120"
                    stroke="var(--shadow-dark)"
                    strokeWidth="8"
                    fill="none"
                    className="opacity-20"
                  />
                  <circle
                    cx="128"
                    cy="128"
                    r="120"
                    stroke="url(#gradient)"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 120}`}
                    strokeDashoffset={`${2 * Math.PI * 120 * (1 - getProgressPercentage() / 100)}`}
                    strokeLinecap="round"
                    className="transition-all duration-1000"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="var(--accent-red)" />
                      <stop offset="100%" stopColor="var(--accent-yellow)" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Time Display */}
                <div className="flex flex-col items-center">
                  <Clock className="w-8 h-8 mb-2" style={{ color: 'var(--accent-red)' }} />
                  <p className="text-5xl font-bold mb-2">{formatTime(timeRemaining)}</p>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {Math.floor(timeRemaining / 60)} min remaining
                  </p>
                </div>
              </div>
            </div>

            {/* Workout Info */}
            <div className="neuro-card p-6">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Exercise</p>
                  <p className="font-bold">{formData.exercise_type}</p>
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Intensity</p>
                  <p className="font-bold">{formData.intensity}</p>
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Expected XP</p>
                  <p className="font-bold text-gradient">
                    +{calculateXP(formData.duration, formData.intensity)}
                  </p>
                </div>
                <div>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Calories</p>
                  <p className="font-bold" style={{ color: 'var(--accent-red)' }}>
                    ~{calculateCalories(formData.duration, formData.intensity)}
                  </p>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex gap-3">
              <button
                onClick={toggleTimer}
                className="neuro-button flex-1 py-4 font-semibold rounded-xl flex items-center justify-center gap-2"
              >
                {timerRunning ? (
                  <>
                    <Pause className="w-5 h-5" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    Resume
                  </>
                )}
              </button>
              <button
                onClick={stopTimer}
                className="neuro-button px-6 py-4 font-semibold rounded-xl flex items-center justify-center gap-2"
              >
                <Square className="w-5 h-5" />
                Stop
              </button>
            </div>
          </div>
        )}

        {step === "complete" && (
          <div className="space-y-6">
            <div className="neuro-card p-8 text-center">
              <CheckCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#4ade80' }} />
              <h2 className="text-2xl font-bold mb-2">Workout Complete! 🎉</h2>
              <p style={{ color: 'var(--text-secondary)' }}>
                You completed {formData.duration} minutes of {formData.exercise_type}
              </p>
            </div>

            {/* Rewards Summary */}
            <div className="neuro-card p-6">
              <h3 className="font-semibold mb-4 text-center">Your Rewards</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-center gap-2">
                  <Zap className="w-6 h-6" style={{ color: 'var(--accent-yellow)' }} />
                  <div>
                    <p className="text-2xl font-bold text-gradient">
                      +{calculateXP(formData.duration, formData.intensity)}
                    </p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>XP Points</p>
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <div>
                    <p className="text-2xl font-bold" style={{ color: 'var(--accent-red)' }}>
                      {calculateCalories(formData.duration, formData.intensity)}
                    </p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Calories</p>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={handleLogWorkout}
              disabled={logWorkoutMutation.isPending}
              className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2"
            >
              {logWorkoutMutation.isPending ? (
                "Logging..."
              ) : (
                <>
                  <CheckCircle className="w-5 h-5" />
                  Log Workout & Earn Rewards
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
