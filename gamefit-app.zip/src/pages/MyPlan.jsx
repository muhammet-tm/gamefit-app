import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Calendar, 
  Target, 
  Zap, 
  TrendingUp, 
  CheckCircle2,
  Clock,
  Dumbbell,
  Brain,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  Sparkles
} from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function MyPlan() {
  const queryClient = useQueryClient();
  const [showGenerator, setShowGenerator] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [feedbackData, setFeedbackData] = useState({
    difficulty_rating: "Just Right",
    completion_status: "Completed All",
    energy_level: "Medium",
    injuries_or_pain: "",
    notes: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: activePlan, isLoading: planLoading } = useQuery({
    queryKey: ['activePlan'],
    queryFn: async () => {
      const plans = await base44.entities.WorkoutPlan.filter({ 
        created_by: user?.email,
        is_active: true 
      }, '-created_date', 1);
      return plans[0] || null;
    },
    enabled: !!user
  });

  const { data: allWorkouts } = useQuery({
    queryKey: ['allUserWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: user?.email }),
    enabled: !!user,
    initialData: []
  });

  const { data: weekFeedback } = useQuery({
    queryKey: ['weekFeedback', activePlan?.id, selectedWeek],
    queryFn: () => base44.entities.WorkoutPlanFeedback.filter({
      plan_id: activePlan?.id,
      week_number: selectedWeek
    }),
    enabled: !!activePlan,
    initialData: []
  });

  const createPlanMutation = useMutation({
    mutationFn: (planData) => base44.entities.WorkoutPlan.create(planData),
    onSuccess: () => {
      queryClient.invalidateQueries(['activePlan']);
      setShowGenerator(false);
    }
  });

  const submitFeedbackMutation = useMutation({
    mutationFn: (feedback) => base44.entities.WorkoutPlanFeedback.create(feedback),
    onSuccess: () => {
      queryClient.invalidateQueries(['weekFeedback']);
      setShowFeedbackForm(false);
      setFeedbackData({
        difficulty_rating: "Just Right",
        completion_status: "Completed All",
        energy_level: "Medium",
        injuries_or_pain: "",
        notes: ""
      });
    }
  });

  const generatePersonalizedPlan = async () => {
    setGenerating(true);
    try {
      const workoutSummary = allWorkouts.slice(0, 10).map(w => 
        `${w.exercise_type} (${w.duration}min, ${w.intensity}, ${w.xp_earned} XP)`
      ).join(', ');

      const recentPerformance = allWorkouts.length > 0 
        ? `Average duration: ${Math.round(allWorkouts.reduce((sum, w) => sum + w.duration, 0) / allWorkouts.length)}min`
        : 'No workout history';

      const prompt = `You are an expert fitness coach creating a personalized 8-week workout plan.

USER PROFILE:
- Name: ${user?.full_name}
- Fitness Goal: ${user?.fitness_goal || 'General Fitness'}
- Current Level: ${user?.level || 1}
- Age: ${user?.age || 'N/A'}
- Recent Workouts: ${workoutSummary || 'None yet'}
- Performance: ${recentPerformance}
- Equipment: ${user?.available_equipment || 'Bodyweight only'}

Create a progressive 8-week plan with:
1. Weekly structure (which days to train)
2. Specific exercises for each day with sets/reps/duration
3. Progressive overload strategy
4. Recovery days
5. Modifications for beginners/advanced

Format as JSON with this structure:
{
  "plan_name": "Descriptive name",
  "week_1": {"day_1": "...", "day_2": "...", ...},
  "week_2": {...},
  ...
  "week_8": {...}
}

Be specific, motivating, and ensure progressive difficulty.`;

      const response = await base44.integrations.Core.InvokeLLM({ 
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            plan_name: { type: "string" },
            week_1: { type: "object" },
            week_2: { type: "object" },
            week_3: { type: "object" },
            week_4: { type: "object" },
            week_5: { type: "object" },
            week_6: { type: "object" },
            week_7: { type: "object" },
            week_8: { type: "object" }
          }
        }
      });

      // Deactivate old plans
      if (activePlan) {
        await base44.entities.WorkoutPlan.update(activePlan.id, { is_active: false });
      }

      // Create new plan
      await createPlanMutation.mutateAsync({
        plan_name: response.plan_name,
        duration_weeks: 8,
        fitness_goal: user?.fitness_goal || 'General Fitness',
        difficulty_level: user?.level > 5 ? 'Advanced' : user?.level > 2 ? 'Intermediate' : 'Beginner',
        weekly_schedule: response,
        equipment_needed: [user?.available_equipment || 'Bodyweight'],
        current_week: 1,
        is_active: true,
        generated_prompt: prompt
      });

    } catch (error) {
      alert("Failed to generate plan. Please try again.");
    }
    setGenerating(false);
  };

  const regeneratePlanWithFeedback = async () => {
    if (!activePlan) return;
    setGenerating(true);
    
    try {
      const feedbacks = await base44.entities.WorkoutPlanFeedback.filter({ 
        plan_id: activePlan.id 
      });
      
      const feedbackSummary = feedbacks.map(f => 
        `Week ${f.week_number}: ${f.difficulty_rating}, ${f.completion_status}, Energy: ${f.energy_level}. Notes: ${f.notes || 'None'}`
      ).join('\n');

      const prompt = `You are an expert fitness coach adapting a workout plan based on user feedback.

ORIGINAL PLAN: ${activePlan.plan_name}
GOAL: ${activePlan.fitness_goal}
CURRENT WEEK: ${activePlan.current_week}
USER LEVEL: ${user?.level}

FEEDBACK FROM USER:
${feedbackSummary || 'No feedback yet'}

INSTRUCTIONS:
Based on the feedback, create an IMPROVED 8-week plan that:
- Adjusts difficulty if user found it too easy/hard
- Addresses any pain/injury concerns
- Maintains progressive overload
- Keeps user motivated

Format as JSON with structure:
{
  "plan_name": "Updated name",
  "week_1": {"day_1": "...", ...},
  ...
  "week_8": {...}
}`;

      const response = await base44.integrations.Core.InvokeLLM({ 
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            plan_name: { type: "string" },
            week_1: { type: "object" },
            week_2: { type: "object" },
            week_3: { type: "object" },
            week_4: { type: "object" },
            week_5: { type: "object" },
            week_6: { type: "object" },
            week_7: { type: "object" },
            week_8: { type: "object" }
          }
        }
      });

      await base44.entities.WorkoutPlan.update(activePlan.id, { is_active: false });

      await createPlanMutation.mutateAsync({
        plan_name: response.plan_name + " (Adapted)",
        duration_weeks: 8,
        fitness_goal: activePlan.fitness_goal,
        difficulty_level: activePlan.difficulty_level,
        weekly_schedule: response,
        equipment_needed: activePlan.equipment_needed,
        current_week: 1,
        is_active: true,
        generated_prompt: prompt
      });

    } catch (error) {
      alert("Failed to regenerate plan. Please try again.");
    }
    setGenerating(false);
  };

  const handleFeedbackSubmit = () => {
    submitFeedbackMutation.mutate({
      ...feedbackData,
      plan_id: activePlan.id,
      week_number: selectedWeek
    });
  };

  if (planLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="neuro-card p-8">
          <p className="text-lg">Loading your plan...</p>
        </div>
      </div>
    );
  }

  if (!activePlan && !showGenerator) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="neuro-card p-8 text-center">
          <div className="neuro-card w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Brain className="w-8 h-8" style={{ color: 'var(--accent-red)' }} />
          </div>
          <h1 className="text-3xl font-bold text-gradient mb-4">AI-Powered Training Plan</h1>
          <p style={{ color: 'var(--text-secondary)' }} className="mb-6">
            Get a personalized 8-week workout plan that adapts to your progress and feedback
          </p>
          <button
            onClick={() => setShowGenerator(true)}
            className="neuro-button-accent px-8 py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2 mx-auto"
          >
            <Sparkles className="w-5 h-5" />
            Generate My Plan
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="neuro-card p-6 text-center">
            <Target className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--accent-red)' }} />
            <h3 className="font-bold mb-2">Personalized</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Based on your goals, history, and equipment
            </p>
          </div>
          <div className="neuro-card p-6 text-center">
            <TrendingUp className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--accent-yellow)' }} />
            <h3 className="font-bold mb-2">Progressive</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Gradually increases in difficulty over 8 weeks
            </p>
          </div>
          <div className="neuro-card p-6 text-center">
            <RotateCcw className="w-8 h-8 mx-auto mb-3" style={{ color: '#3b82f6' }} />
            <h3 className="font-bold mb-2">Adaptive</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Adjusts based on your weekly feedback
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (showGenerator) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="neuro-card p-8">
          <h2 className="text-2xl font-bold mb-6">Generating Your Personalized Plan</h2>
          
          {generating ? (
            <div className="neuro-card-inset p-12 rounded-xl text-center">
              <div className="animate-pulse space-y-3 mb-6">
                <div className="h-4 bg-gray-300 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-gray-300 rounded w-full"></div>
                <div className="h-4 bg-gray-300 rounded w-5/6 mx-auto"></div>
              </div>
              <p style={{ color: 'var(--text-secondary)' }}>
                AI is analyzing your fitness profile and creating your custom plan...
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="neuro-card-inset p-6 rounded-xl">
                <h3 className="font-bold mb-3">Your Profile</h3>
                <div className="space-y-2 text-sm">
                  <p><strong>Goal:</strong> {user?.fitness_goal || 'Not set'}</p>
                  <p><strong>Level:</strong> {user?.level || 1}</p>
                  <p><strong>Workouts Logged:</strong> {allWorkouts.length}</p>
                  <p><strong>Equipment:</strong> {user?.available_equipment || 'Bodyweight only'}</p>
                </div>
              </div>
              
              <button
                onClick={generatePersonalizedPlan}
                className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2"
              >
                <Brain className="w-5 h-5" />
                Generate 8-Week Plan
              </button>
              
              <button
                onClick={() => setShowGenerator(false)}
                className="neuro-button w-full py-3 font-semibold"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  const weekSchedule = activePlan?.weekly_schedule?.[`week_${selectedWeek}`] || {};
  const weekDays = Object.entries(weekSchedule).sort();
  const hasFeedback = weekFeedback && weekFeedback.length > 0;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="neuro-card p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gradient mb-2">{activePlan.plan_name}</h1>
            <p style={{ color: 'var(--text-secondary)' }}>
              {activePlan.fitness_goal} • {activePlan.difficulty_level} • {activePlan.duration_weeks} weeks
            </p>
          </div>
          <button
            onClick={regeneratePlanWithFeedback}
            disabled={generating}
            className="neuro-button px-4 py-2 font-semibold flex items-center gap-2"
          >
            <RotateCcw className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
            Adapt Plan
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <div className="neuro-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4" style={{ color: 'var(--accent-red)' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Current Week</span>
          </div>
          <p className="text-2xl font-bold">{activePlan.current_week} / {activePlan.duration_weeks}</p>
        </div>
        <div className="neuro-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="w-4 h-4" style={{ color: '#4ade80' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Completion</span>
          </div>
          <p className="text-2xl font-bold">{activePlan.completion_rate || 0}%</p>
        </div>
        <div className="neuro-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Dumbbell className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Equipment</span>
          </div>
          <p className="text-sm font-bold">{activePlan.equipment_needed?.join(', ') || 'None'}</p>
        </div>
        <div className="neuro-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4" style={{ color: '#3b82f6' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>This Week</span>
          </div>
          <p className="text-sm font-bold">{weekDays.length} workouts</p>
        </div>
      </div>

      <div className="neuro-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Week {selectedWeek}</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedWeek(Math.max(1, selectedWeek - 1))}
              disabled={selectedWeek === 1}
              className="neuro-button p-2 disabled:opacity-50"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setSelectedWeek(Math.min(activePlan.duration_weeks, selectedWeek + 1))}
              disabled={selectedWeek === activePlan.duration_weeks}
              className="neuro-button p-2 disabled:opacity-50"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {weekDays.map(([day, workout]) => (
            <div key={day} className="neuro-card-inset p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4" style={{ color: 'var(--accent-red)' }} />
                <h3 className="font-bold capitalize">{day.replace('_', ' ')}</h3>
              </div>
              <div className="prose prose-sm max-w-none">
                <ReactMarkdown>{workout}</ReactMarkdown>
              </div>
            </div>
          ))}
        </div>

        {!hasFeedback && selectedWeek <= activePlan.current_week && (
          <button
            onClick={() => setShowFeedbackForm(true)}
            className="neuro-button-accent w-full mt-6 py-3 text-white font-semibold rounded-xl"
          >
            Share Week {selectedWeek} Feedback
          </button>
        )}

        {hasFeedback && (
          <div className="neuro-card-inset p-6 rounded-xl mt-6">
            <h3 className="font-bold mb-3">Your Feedback (Week {selectedWeek})</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Difficulty:</strong> {weekFeedback[0].difficulty_rating}</p>
              <p><strong>Completion:</strong> {weekFeedback[0].completion_status}</p>
              <p><strong>Energy:</strong> {weekFeedback[0].energy_level}</p>
              {weekFeedback[0].notes && <p><strong>Notes:</strong> {weekFeedback[0].notes}</p>}
            </div>
          </div>
        )}
      </div>

      {showFeedbackForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="neuro-card p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Week {selectedWeek} Feedback</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2">How was the difficulty?</label>
                <div className="neuro-card-inset p-1 rounded-xl">
                  <select
                    value={feedbackData.difficulty_rating}
                    onChange={(e) => setFeedbackData({...feedbackData, difficulty_rating: e.target.value})}
                    className="w-full px-4 py-3 bg-transparent outline-none"
                  >
                    <option value="Too Easy">Too Easy</option>
                    <option value="Just Right">Just Right</option>
                    <option value="Too Hard">Too Hard</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">How much did you complete?</label>
                <div className="neuro-card-inset p-1 rounded-xl">
                  <select
                    value={feedbackData.completion_status}
                    onChange={(e) => setFeedbackData({...feedbackData, completion_status: e.target.value})}
                    className="w-full px-4 py-3 bg-transparent outline-none"
                  >
                    <option value="Completed All">Completed All</option>
                    <option value="Completed Most">Completed Most</option>
                    <option value="Completed Some">Completed Some</option>
                    <option value="Completed None">Completed None</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Energy Level</label>
                <div className="neuro-card-inset p-1 rounded-xl">
                  <select
                    value={feedbackData.energy_level}
                    onChange={(e) => setFeedbackData({...feedbackData, energy_level: e.target.value})}
                    className="w-full px-4 py-3 bg-transparent outline-none"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Any injuries or pain?</label>
                <div className="neuro-card-inset p-3 rounded-xl">
                  <input
                    type="text"
                    value={feedbackData.injuries_or_pain}
                    onChange={(e) => setFeedbackData({...feedbackData, injuries_or_pain: e.target.value})}
                    placeholder="e.g., knee soreness"
                    className="w-full bg-transparent outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Additional notes</label>
                <div className="neuro-card-inset p-3 rounded-xl">
                  <textarea
                    value={feedbackData.notes}
                    onChange={(e) => setFeedbackData({...feedbackData, notes: e.target.value})}
                    placeholder="Share your thoughts..."
                    className="w-full bg-transparent outline-none h-24 resize-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={handleFeedbackSubmit}
                disabled={submitFeedbackMutation.isPending}
                className="neuro-button-accent flex-1 py-3 text-white font-semibold rounded-xl"
              >
                Submit Feedback
              </button>
              <button
                onClick={() => setShowFeedbackForm(false)}
                className="neuro-button px-6 py-3 font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}