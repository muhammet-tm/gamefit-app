
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Brain, Sparkles, Dumbbell, Apple, Target, Send, ArrowRight, Crown, Lock } from "lucide-react";
import ReactMarkdown from "react-markdown";

import GameFitLogo from "../components/shared/GameFitLogo";

export default function AICoach() {
  const [activeTab, setActiveTab] = useState("plan");
  const [customQuery, setCustomQuery] = useState("");
  const [aiResponse, setAiResponse] = useState(null);
  const [exerciseGifs, setExerciseGifs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showQuestions, setShowQuestions] = useState(true);
  const [questionData, setQuestionData] = useState({});

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: recentWorkouts } = useQuery({
    queryKey: ['recentWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: user?.email }, '-created_date', 10),
    enabled: !!user,
    initialData: []
  });

  const isPremium = user?.subscription_tier === "Premium";

  const workoutPlanQuestions = [
    { id: "available_days", label: "Workout Days per Week", type: "number", min: 1, max: 7, default: 3 },
    { id: "session_duration", label: "Minutes per Session", type: "number", min: 15, max: 180, default: 45 },
    { id: "equipment", label: "Available Equipment", type: "select", options: ["None (Bodyweight)", "Dumbbells", "Full Gym", "Home Gym"], default: "None (Bodyweight)" },
    { id: "injuries", label: "Any Injuries/Limitations?", type: "text", placeholder: "e.g., knee pain, lower back issues" }
  ];

  const nutritionQuestions = [
    { id: "meals_per_day", label: "Preferred Meals per Day", type: "number", min: 1, max: 6, default: 3 },
    { id: "dietary_restrictions", label: "Dietary Restrictions", type: "select", options: ["None", "Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free", "Keto"], default: "None" },
    { id: "allergies", label: "Food Allergies", type: "text", placeholder: "e.g., nuts, shellfish" },
    { id: "cuisine_preference", label: "Cuisine Preference", type: "text", placeholder: "e.g., Mediterranean, Asian" }
  ];

  const formQuestions = [
    { id: "exercises", label: "Which Exercises?", type: "text", placeholder: "e.g., squats, deadlifts, push-ups", required: true },
    { id: "experience_level", label: "Experience Level", type: "select", options: ["Beginner", "Intermediate", "Advanced"], default: "Beginner" },
    { id: "specific_concerns", label: "Specific Concerns", type: "text", placeholder: "e.g., wrist pain during push-ups" }
  ];

  const marathonQuestions = [
    { id: "current_distance", label: "Current Long Run Distance (km)", type: "number", min: 1, max: 42, default: 5 },
    { id: "target_time", label: "Target Marathon Time", type: "text", placeholder: "e.g., 4:00:00" },
    { id: "race_date", label: "Race Date (weeks away)", type: "number", min: 4, max: 52, default: 16 }
  ];

  const strengthQuestions = [
    { id: "focus_area", label: "Focus Area", type: "select", options: ["Full Body", "Upper Body", "Lower Body", "Core"], default: "Full Body" },
    { id: "training_days", label: "Training Days per Week", type: "number", min: 2, max: 6, default: 4 },
    { id: "current_level", label: "Current Strength Level", type: "select", options: ["Beginner", "Intermediate", "Advanced"], default: "Beginner" }
  ];

  const getQuestionsForTab = () => {
    switch(activeTab) {
      case "plan": return workoutPlanQuestions;
      case "nutrition": return nutritionQuestions;
      case "form": return formQuestions;
      case "marathon": return marathonQuestions;
      case "strength": return strengthQuestions;
      default: return [];
    }
  };

  const generateWorkoutPlan = async () => {
    setIsLoading(true);
    try {
      const workoutSummary = recentWorkouts.map(w => 
        `${w.exercise_type} (${w.duration}min, ${w.intensity})`
      ).join(', ');

      const prompt = `You are a professional fitness coach. Create a personalized weekly workout plan for:
      - Goal: ${user?.fitness_goal || 'General Fitness'}
      - Current Level: ${user?.level || 1}
      - Age: ${user?.age || 'N/A'}
      - Recent workouts: ${workoutSummary || 'None yet'}
      - Available days: ${questionData.available_days || 3} days/week
      - Session duration: ${questionData.session_duration || 45} minutes
      - Equipment: ${questionData.equipment || 'None'}
      - Injuries/Limitations: ${questionData.injuries || 'None'}
      
      Provide a structured 7-day plan with specific exercises, sets, reps, and duration. Make it motivating and achievable!`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't generate a plan right now. Please try again.");
    }
    setIsLoading(false);
  };

  const generateMarathonPlan = async () => {
    setIsLoading(true);
    try {
      const prompt = `You are an elite running coach specializing in marathon training. Create a detailed ${questionData.race_date || 16}-week marathon training plan for:
      - Current long run distance: ${questionData.current_distance || 5} km
      - Target finish time: ${questionData.target_time || '4:00:00'}
      - Race date: ${questionData.race_date || 16} weeks away
      
      Include:
      1. Weekly mileage progression
      2. Long run schedule with pacing
      3. Speed/tempo workout days
      4. Recovery and cross-training
      5. Taper strategy
      6. Race day tips
      
      Make it progressive, safe, and marathon-specific!`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't generate a marathon plan right now. Please try again.");
    }
    setIsLoading(false);
  };

  const generateStrengthProgram = async () => {
    setIsLoading(true);
    try {
      const prompt = `You are a certified strength and conditioning coach. Create a comprehensive strength building program for:
      - Focus area: ${questionData.focus_area || 'Full Body'}
      - Training days: ${questionData.training_days || 4} per week
      - Current level: ${questionData.current_level || 'Beginner'}
      - Goal: Build muscle and increase strength
      
      Include:
      1. Exercise selection with proper progressions
      2. Sets, reps, and rest periods
      3. Progressive overload strategy
      4. Deload weeks
      5. Nutrition tips for muscle growth
      6. Form cues for key lifts
      
      Make it effective and focused on strength gains!`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't generate a strength program right now. Please try again.");
    }
    setIsLoading(false);
  };

  const generateNutritionAdvice = async () => {
    setIsLoading(true);
    try {
      const prompt = `You are a certified nutritionist. Provide personalized nutrition advice for:
      - Fitness Goal: ${user?.fitness_goal || 'General Fitness'}
      - Weight: ${user?.weight || 'N/A'} kg
      - Height: ${user?.height || 'N/A'} cm
      - Age: ${user?.age || 'N/A'}
      - Meals per day: ${questionData.meals_per_day || 3}
      - Dietary restrictions: ${questionData.dietary_restrictions || 'None'}
      - Allergies: ${questionData.allergies || 'None'}
      - Cuisine preference: ${questionData.cuisine_preference || 'Any'}
      
      Include: daily calories, macros, sample meals, timing, hydration, and pre/post workout nutrition.`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't generate nutrition advice right now. Please try again.");
    }
    setIsLoading(false);
  };

  const generateFormAdvice = async () => {
    setIsLoading(true);
    try {
      const exercises = questionData.exercises || recentWorkouts.map(w => w.exercise_type).join(', ') || 'various exercises';
      const prompt = `You are an expert fitness coach specializing in exercise form. Provide detailed form tips for: ${exercises}
      Experience: ${questionData.experience_level || 'Beginner'}
      Concerns: ${questionData.specific_concerns || 'None'}
      
      Include: setup, cues, mistakes to avoid, injury prevention, and progressions.`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't generate form advice right now. Please try again.");
    }
    setIsLoading(false);
  };

  const handleCustomQuery = async () => {
    if (!customQuery.trim()) return;
    setIsLoading(true);
    try {
      const prompt = `You are a professional fitness coach. Answer: "${customQuery}"
      User context: Goal: ${user?.fitness_goal}, Level: ${user?.level}, Activity: ${recentWorkouts.length} workouts`;

      const response = await base44.integrations.Core.InvokeLLM({ prompt, add_context_from_internet: true });
      setAiResponse(response);
    } catch (error) {
      setAiResponse("Sorry, I couldn't answer your question right now. Please try again.");
    }
    setIsLoading(false);
  };

  const handleGenerate = () => {
    setShowQuestions(false);
    switch(activeTab) {
      case "plan": generateWorkoutPlan(); break;
      case "nutrition": generateNutritionAdvice(); break;
      case "form": generateFormAdvice(); break;
      case "marathon": generateMarathonPlan(); break;
      case "strength": generateStrengthProgram(); break;
    }
  };

  const handlePremiumFeature = () => {
    alert("This is a Premium feature! Upgrade to access specialized AI coaching programs.");
  };

  const tabs = [
    { id: "plan", label: "Workout Plan", icon: Dumbbell, premium: false },
    { id: "nutrition", label: "Nutrition", icon: Apple, premium: false },
    { id: "form", label: "Form Tips", icon: Target, premium: false },
    { id: "marathon", label: "Marathon Training", icon: Crown, premium: true },
    { id: "strength", label: "Strength Building", icon: Crown, premium: true },
    { id: "chat", label: "Ask Coach", icon: Brain, premium: false }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="neuro-card p-8">
        <div className="flex items-center justify-between mb-4">
          <GameFitLogo size="default" />
          {isPremium && (
            <div className="flex items-center gap-2 neuro-card px-4 py-2">
              <Crown className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
              <span className="text-sm font-bold text-gradient">Premium</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-4">
          <div className="neuro-card p-4">
            <Brain className="w-8 h-8" style={{ color: '#8b5cf6' }} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gradient">AI Fitness Coach</h1>
            <p style={{ color: 'var(--text-secondary)' }}>
              Your personal AI trainer, available 24/7
            </p>
          </div>
        </div>
      </div>

      <div className="neuro-card p-2">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isLocked = tab.premium && !isPremium;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  if (isLocked) {
                    handlePremiumFeature();
                    return;
                  }
                  setActiveTab(tab.id);
                  setAiResponse(null);
                  setExerciseGifs([]);
                  setShowQuestions(true);
                  setQuestionData({});
                }}
                className={`neuro-button p-3 flex items-center justify-center gap-2 relative ${
                  activeTab === tab.id && !isLocked ? 'nav-item-active' : ''
                } ${isLocked ? 'opacity-70' : ''}`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-semibold text-xs">{tab.label}</span>
                {isLocked && <Lock className="w-3 h-3 absolute top-1 right-1" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="neuro-card p-8">
        {activeTab === "chat" ? (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold mb-2">Ask Your Coach Anything</h2>
              <p style={{ color: 'var(--text-secondary)' }} className="text-sm mb-4">
                Get personalized fitness advice, exercise tips, or nutrition guidance
              </p>
            </div>
            <div className="neuro-card-inset p-4 rounded-xl flex gap-3">
              <input
                type="text"
                value={customQuery}
                onChange={(e) => setCustomQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCustomQuery()}
                placeholder="e.g., How can I improve my running endurance?"
                className="flex-1 bg-transparent outline-none"
                disabled={isLoading}
              />
              <button
                onClick={handleCustomQuery}
                disabled={isLoading || !customQuery.trim()}
                className="neuro-button-accent px-6 py-2 text-white font-semibold rounded-xl flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                Ask
              </button>
            </div>
          </div>
        ) : showQuestions && !aiResponse ? (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold mb-2">
                Let's personalize your {tabs.find(t => t.id === activeTab)?.label}
              </h2>
              <p style={{ color: 'var(--text-secondary)' }} className="text-sm">
                Answer a few questions to get the best recommendations
              </p>
            </div>

            <div className="space-y-4">
              {getQuestionsForTab().map((question) => (
                <div key={question.id}>
                  <label className="block text-sm font-semibold mb-2">
                    {question.label} {question.required && <span style={{ color: 'var(--accent-red)' }}>*</span>}
                  </label>
                  {question.type === "select" ? (
                    <div className="neuro-card-inset p-1 rounded-xl">
                      <select
                        value={questionData[question.id] || question.default || ""}
                        onChange={(e) => setQuestionData({...questionData, [question.id]: e.target.value})}
                        className="w-full px-4 py-3 bg-transparent outline-none"
                      >
                        {question.options.map((opt) => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>
                  ) : question.type === "number" ? (
                    <div className="neuro-card-inset p-4 rounded-xl">
                      <input
                        type="number"
                        min={question.min}
                        max={question.max}
                        value={questionData[question.id] || question.default || ""}
                        onChange={(e) => setQuestionData({...questionData, [question.id]: e.target.value})}
                        className="w-full bg-transparent outline-none"
                      />
                    </div>
                  ) : (
                    <div className="neuro-card-inset p-4 rounded-xl">
                      <input
                        type="text"
                        placeholder={question.placeholder}
                        value={questionData[question.id] || ""}
                        onChange={(e) => setQuestionData({...questionData, [question.id]: e.target.value})}
                        className="w-full bg-transparent outline-none"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={handleGenerate}
              className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2"
            >
              <ArrowRight className="w-5 h-5" />
              Generate {tabs.find(t => t.id === activeTab)?.label}
            </button>
          </div>
        ) : (
          !aiResponse && !isLoading && (
            <button
              onClick={handleGenerate}
              className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              Generate {tabs.find(t => t.id === activeTab)?.label}
            </button>
          )
        )}

        {aiResponse && (
          <div className="mt-6 space-y-6">
            {exerciseGifs.length > 0 && (
              <div className="neuro-card p-6 rounded-xl">
                <h3 className="font-bold mb-4 flex items-center gap-2">
                  <Dumbbell className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
                  Exercise Demonstrations
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {exerciseGifs.map((gif, idx) => (
                    <div key={idx} className="neuro-card-inset rounded-xl overflow-hidden">
                      <img src={gif} alt={`Exercise ${idx + 1}`} className="w-full h-auto" onError={(e) => e.target.style.display = 'none'} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="neuro-card-inset p-6 rounded-xl">
              <div className="prose prose-sm max-w-none">
                <ReactMarkdown>
                  {aiResponse}
                </ReactMarkdown>
              </div>
            </div>

            <button
              onClick={() => {
                setAiResponse(null);
                setExerciseGifs([]);
                setCustomQuery("");
                setShowQuestions(true);
              }}
              className="neuro-button px-6 py-2 font-semibold"
            >
              Generate New Response
            </button>
          </div>
        )}

        {isLoading && (
          <div className="mt-6 neuro-card-inset p-8 rounded-xl text-center">
            <div className="animate-pulse space-y-3">
              <div className="h-4 bg-gray-300 rounded w-3/4 mx-auto"></div>
              <div className="h-4 bg-gray-300 rounded w-full"></div>
              <div className="h-4 bg-gray-300 rounded w-5/6 mx-auto"></div>
            </div>
            <p className="mt-4" style={{ color: 'var(--text-secondary)' }}>
              Your AI coach is thinking...
            </p>
          </div>
        )}
      </div>

      <div className="neuro-card p-4 text-center">
        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
          💡 AI Coach provides general fitness guidance. Always consult healthcare professionals for medical advice.
        </p>
      </div>
    </div>
  );
}
