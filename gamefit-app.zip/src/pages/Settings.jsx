
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings as SettingsIcon, Crown, Shield, LogOut, User, Bell } from "lucide-react";

import GameFitLogo from "../components/shared/GameFitLogo";
import PricingCard from "../components/subscription/PricingCard";
import SubscriptionBenefits from "../components/subscription/SubscriptionBenefits";

export default function Settings() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("subscription");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const upgradeToPremiumMutation = useMutation({
    mutationFn: () => base44.auth.updateMe({ subscription_tier: "Premium" }),
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
      alert("🎉 Welcome to GameFit Premium! Enjoy your exclusive benefits!");
    }
  });

  const downgradeMutation = useMutation({
    mutationFn: () => base44.auth.updateMe({ subscription_tier: "Free" }),
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
      alert("Your subscription has been downgraded to Free tier.");
    }
  });

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      base44.auth.logout();
    }
  };

  const isPremium = user?.subscription_tier === "Premium";

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="neuro-card p-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="neuro-card p-4">
            <SettingsIcon className="w-8 h-8" style={{ color: 'var(--accent-red)' }} />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Settings</h1>
            <p style={{ color: 'var(--text-secondary)' }}>
              Manage your account and subscription
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="neuro-card p-2 mb-6">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab("subscription")}
              className={`neuro-button flex-1 py-3 flex items-center justify-center gap-2 ${
                activeTab === "subscription" ? 'nav-item-active' : ''
              }`}
            >
              <Crown className="w-5 h-5" />
              <span className="font-semibold">Subscription</span>
            </button>
            <button
              onClick={() => setActiveTab("account")}
              className={`neuro-button flex-1 py-3 flex items-center justify-center gap-2 ${
                activeTab === "account" ? 'nav-item-active' : ''
              }`}
            >
              <User className="w-5 h-5" />
              <span className="font-semibold">Account</span>
            </button>
          </div>
        </div>

        {/* Content */}
        {activeTab === "subscription" && (
          <div className="space-y-6">
            {/* Current Plan */}
            <div className="neuro-card p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-lg mb-1">Current Plan</h3>
                  <div className="flex items-center gap-2">
                    {isPremium ? (
                      <>
                        <Crown className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
                        <span className="font-bold text-gradient">Premium</span>
                      </>
                    ) : (
                      <>
                        <Shield className="w-5 h-5" style={{ color: 'var(--text-secondary)' }} />
                        <span className="font-semibold">Free</span>
                      </>
                    )}
                  </div>
                </div>
                {isPremium && (
                  <button
                    onClick={() => {
                      if (window.confirm("Are you sure you want to downgrade to Free?")) {
                        downgradeMutation.mutate();
                      }
                    }}
                    className="neuro-button px-4 py-2 text-sm"
                  >
                    Downgrade to Free
                  </button>
                )}
              </div>
              {isPremium && (
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  You have access to all Premium features. Thank you for supporting GameFit!
                </p>
              )}
            </div>

            {/* Benefits Comparison */}
            <SubscriptionBenefits currentTier={user?.subscription_tier} />

            {/* Pricing Cards */}
            {!isPremium && (
              <div className="grid md:grid-cols-2 gap-6">
                <PricingCard
                  tier="Free"
                  price="$0"
                  features={[
                    "Basic workout logging",
                    "Avatar customization",
                    "Global leaderboards",
                    "Basic AI Coach advice",
                    "Community access"
                  ]}
                  isCurrent={true}
                />
                <PricingCard
                  tier="Premium"
                  price="$9.99"
                  period="/month"
                  features={[
                    "Everything in Free",
                    "Advanced analytics & reports",
                    "Exclusive avatar items",
                    "Specialized AI coaching",
                    "Priority feature access",
                    "Ad-free experience"
                  ]}
                  isPremium={true}
                  onUpgrade={() => upgradeToPremiumMutation.mutate()}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === "account" && (
          <div className="space-y-6">
            <div className="neuro-card p-6">
              <h3 className="font-bold text-lg mb-4">Account Information</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span style={{ color: 'var(--text-secondary)' }}>Email</span>
                  <span className="font-semibold">{user?.email}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span style={{ color: 'var(--text-secondary)' }}>Name</span>
                  <span className="font-semibold">{user?.full_name}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span style={{ color: 'var(--text-secondary)' }}>Member Since</span>
                  <span className="font-semibold">
                    {new Date(user?.created_date).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="neuro-button w-full py-4 flex items-center justify-center gap-2 font-semibold"
              style={{ color: 'var(--accent-red)' }}
            >
              <LogOut className="w-5 h-5" />
              Log Out
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
