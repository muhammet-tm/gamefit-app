import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Award, Trophy, Lock, Star, Target, TrendingUp, Flame, Zap } from "lucide-react";

export default function Achievements() {
  const [filter, setFilter] = useState("all");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: achievements } = useQuery({
    queryKey: ['achievements'],
    queryFn: () => base44.entities.Achievement.list(),
    initialData: []
  });

  const { data: userAchievements } = useQuery({
    queryKey: ['userAchievements', user?.email],
    queryFn: () => base44.entities.UserAchievement.filter({ user_email: user?.email }),
    enabled: !!user,
    initialData: []
  });

  const { data: allWorkouts } = useQuery({
    queryKey: ['allUserWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: user?.email }),
    enabled: !!user,
    initialData: []
  });

  const isAchievementUnlocked = (achievement) => {
    return userAchievements.some(ua => ua.achievement_id === achievement.id);
  };

  const getAchievementProgress = (achievement) => {
    if (!user) return 0;

    switch (achievement.requirement_type) {
      case "workouts_count":
        return Math.min((allWorkouts.length / achievement.requirement_value) * 100, 100);
      
      case "total_xp":
        return Math.min(((user.total_xp || 0) / achievement.requirement_value) * 100, 100);
      
      case "streak_days":
        return Math.min(((user.best_streak || 0) / achievement.requirement_value) * 100, 100);
      
      case "level":
        return Math.min(((user.level || 1) / achievement.requirement_value) * 100, 100);
      
      default:
        return 0;
    }
  };

  const getIconComponent = (iconName) => {
    const icons = {
      Trophy, Award, Star, Target, TrendingUp, Flame, Zap
    };
    return icons[iconName] || Award;
  };

  const earnedAchievements = achievements.filter(a => isAchievementUnlocked(a));
  const lockedAchievements = achievements.filter(a => !isAchievementUnlocked(a));

  const filteredAchievements = filter === "earned" 
    ? earnedAchievements 
    : filter === "locked" 
    ? lockedAchievements 
    : achievements;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="neuro-card p-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="neuro-card p-4">
              <Trophy className="w-8 h-8" style={{ color: 'var(--accent-yellow)' }} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gradient">Achievements</h1>
              <p style={{ color: 'var(--text-secondary)' }}>
                Unlock badges and earn rewards
              </p>
            </div>
          </div>

          <div className="neuro-card p-4">
            <div className="text-center">
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Unlocked</p>
              <p className="text-3xl font-bold text-gradient">
                {earnedAchievements.length}/{achievements.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="neuro-card p-4">
        <div className="flex gap-2">
          <button
            onClick={() => setFilter("all")}
            className={`neuro-button px-4 py-2 ${filter === "all" ? 'nav-item-active' : ''}`}
          >
            All
          </button>
          <button
            onClick={() => setFilter("earned")}
            className={`neuro-button px-4 py-2 ${filter === "earned" ? 'nav-item-active' : ''}`}
          >
            Earned ({earnedAchievements.length})
          </button>
          <button
            onClick={() => setFilter("locked")}
            className={`neuro-button px-4 py-2 ${filter === "locked" ? 'nav-item-active' : ''}`}
          >
            Locked ({lockedAchievements.length})
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAchievements.map((achievement) => {
          const unlocked = isAchievementUnlocked(achievement);
          const progress = getAchievementProgress(achievement);
          const Icon = getIconComponent(achievement.icon);

          return (
            <div 
              key={achievement.id} 
              className={`neuro-card p-6 ${unlocked ? '' : 'opacity-70'}`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div 
                  className="neuro-card p-3 rounded-xl"
                  style={{ 
                    background: unlocked ? achievement.badge_color : 'var(--bg-base)'
                  }}
                >
                  {unlocked ? (
                    <Icon className="w-8 h-8" style={{ color: '#fff' }} />
                  ) : (
                    <Lock className="w-8 h-8" style={{ color: 'var(--text-secondary)' }} />
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-1">{achievement.title}</h3>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {achievement.description}
                  </p>
                </div>
              </div>

              {!unlocked && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span style={{ color: 'var(--text-secondary)' }}>Progress</span>
                    <span className="font-semibold">{Math.round(progress)}%</span>
                  </div>
                  <div className="neuro-card-inset rounded-full h-2 overflow-hidden">
                    <div 
                      className="h-full transition-all duration-500"
                      style={{ 
                        width: `${progress}%`,
                        background: 'linear-gradient(90deg, var(--accent-red), var(--accent-yellow))'
                      }}
                    />
                  </div>
                </div>
              )}

              <div className="mt-4 pt-4 border-t border-gray-300 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {achievement.reward_coins > 0 && (
                    <div className="flex items-center gap-1">
                      <Award className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
                      <span className="text-sm font-semibold">{achievement.reward_coins}</span>
                    </div>
                  )}
                  {achievement.reward_xp > 0 && (
                    <div className="flex items-center gap-1">
                      <Zap className="w-4 h-4" style={{ color: 'var(--accent-red)' }} />
                      <span className="text-sm font-semibold">{achievement.reward_xp}</span>
                    </div>
                  )}
                </div>
                {unlocked && (
                  <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{ background: '#4ade8020', color: '#4ade80' }}>
                    ✓ Unlocked
                  </span>
                )}
              </div>

              {achievement.unlocks_avatar_item && (
                <div className="mt-2 text-xs text-center p-2 rounded-lg" style={{ background: 'var(--accent-yellow)20', color: 'var(--accent-yellow)' }}>
                  🎁 Unlocks: {achievement.unlocks_avatar_item}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filteredAchievements.length === 0 && (
        <div className="neuro-card p-12 text-center">
          <Trophy className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-secondary)' }} />
          <p style={{ color: 'var(--text-secondary)' }}>
            No achievements in this category yet.
          </p>
        </div>
      )}
    </div>
  );
}