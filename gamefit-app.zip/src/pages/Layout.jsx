
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Home, 
  Dumbbell, 
  Trophy, 
  User, 
  Brain, 
  ShoppingBag,
  Menu,
  X,
  Settings as SettingsIcon,
  Award,
  Calendar
} from "lucide-react";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigationItems = [
    { title: "Dashboard", url: createPageUrl("Dashboard"), icon: Home },
    { title: "My Plan", url: createPageUrl("MyPlan"), icon: Calendar },
    { title: "Log Workout", url: createPageUrl("WorkoutLog"), icon: Dumbbell },
    { title: "Achievements", url: createPageUrl("Achievements"), icon: Award },
    { title: "AI Coach", url: createPageUrl("AICoach"), icon: Brain },
    { title: "Leaderboard", url: createPageUrl("Leaderboard"), icon: Trophy },
    { title: "Marketplace", url: createPageUrl("Marketplace"), icon: ShoppingBag },
    { title: "Profile", url: createPageUrl("Profile"), icon: User },
    { title: "Settings", url: createPageUrl("Settings"), icon: SettingsIcon },
  ];

  return (
    <>
      <style>{`
        :root {
          --bg-base: #e0e0e0;
          --text-primary: #2d2d2d;
          --text-secondary: #666666;
          --accent-red: #c41e3a;
          --accent-yellow: #ffa500;
          --shadow-light: #ffffff;
          --shadow-dark: #a3a3a3;
        }

        body {
          background: var(--bg-base);
          color: var(--text-primary);
        }

        .neuro-card {
          background: var(--bg-base);
          border-radius: 20px;
          box-shadow: 8px 8px 16px var(--shadow-dark), -8px -8px 16px var(--shadow-light);
        }

        .neuro-card-inset {
          background: var(--bg-base);
          border-radius: 20px;
          box-shadow: inset 6px 6px 12px var(--shadow-dark), inset -6px -6px 12px var(--shadow-light);
        }

        .neuro-button {
          background: var(--bg-base);
          border-radius: 12px;
          box-shadow: 6px 6px 12px var(--shadow-dark), -6px -6px 12px var(--shadow-light);
          transition: all 0.2s ease;
          border: none;
        }

        .neuro-button:hover {
          box-shadow: 4px 4px 8px var(--shadow-dark), -4px -4px 8px var(--shadow-light);
        }

        .neuro-button:active {
          box-shadow: inset 4px 4px 8px var(--shadow-dark), inset -4px -4px 8px var(--shadow-light);
        }

        .neuro-button-accent {
          background: linear-gradient(145deg, #d41e3a, #a01528);
          box-shadow: 6px 6px 12px var(--shadow-dark), -6px -6px 12px var(--shadow-light);
        }

        .neuro-button-accent:hover {
          background: linear-gradient(145deg, #e02545, #b01830);
        }

        .neuro-button-accent:active {
          box-shadow: inset 4px 4px 8px rgba(0,0,0,0.3), inset -4px -4px 8px rgba(255,255,255,0.1);
        }

        .nav-item-active {
          background: var(--bg-base);
          box-shadow: inset 4px 4px 8px var(--shadow-dark), inset -4px -4px 8px var(--shadow-light);
        }

        .text-gradient {
          background: linear-gradient(135deg, var(--accent-red), var(--accent-yellow));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>

      <div className="min-h-screen" style={{ background: 'var(--bg-base)' }}>
        <header className="neuro-card sticky top-0 z-50 mb-6">
          <div className="px-4 py-4">
            <div className="flex items-center justify-between max-w-7xl mx-auto">
              <div className="flex items-center gap-3">
                <div className="neuro-card w-12 h-12 flex items-center justify-center">
                  <Dumbbell className="w-6 h-6" style={{ color: 'var(--accent-red)' }} />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gradient">GameFit</h1>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                    Level Up Your Fitness
                  </p>
                </div>
              </div>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="neuro-button p-3 md:hidden"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>

              <nav className="hidden md:flex items-center gap-2">
                {navigationItems.map((item) => {
                  const isActive = location.pathname === item.url;
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.title}
                      to={item.url}
                      className={`neuro-button px-4 py-2 flex items-center gap-2 ${
                        isActive ? 'nav-item-active' : ''
                      }`}
                    >
                      <Icon className="w-4 h-4" style={{ color: isActive ? 'var(--accent-red)' : 'var(--text-secondary)' }} />
                      <span className={isActive ? 'font-semibold' : ''} style={{ color: isActive ? 'var(--accent-red)' : 'var(--text-primary)' }}>
                        {item.title}
                      </span>
                    </Link>
                  );
                })}
              </nav>
            </div>
          </div>
        </header>

        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-40 pt-20" style={{ background: 'rgba(0,0,0,0.3)' }}>
            <div className="neuro-card m-4 p-4">
              <nav className="flex flex-col gap-2">
                {navigationItems.map((item) => {
                  const isActive = location.pathname === item.url;
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.title}
                      to={item.url}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`neuro-button px-4 py-3 flex items-center gap-3 ${
                        isActive ? 'nav-item-active' : ''
                      }`}
                    >
                      <Icon className="w-5 h-5" style={{ color: isActive ? 'var(--accent-red)' : 'var(--text-secondary)' }} />
                      <span className={isActive ? 'font-semibold' : ''}>
                        {item.title}
                      </span>
                    </Link>
                  );
                })}
              </nav>
            </div>
          </div>
        )}

        <main className="px-4 pb-8 max-w-7xl mx-auto">
          {children}
        </main>
      </div>
    </>
  );
}
