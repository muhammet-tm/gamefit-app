
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  User, 
  Edit2, 
  Trophy, 
  Flame, 
  Target,
  Award,
  Save,
  X,
  TrendingUp,
  Activity
} from "lucide-react";
import { format, subDays } from "date-fns";

import AvatarDisplay from "../components/dashboard/AvatarDisplay";
import AvatarCustomizer from "../components/profile/AvatarCustomizer";
import GameFitLogo from "../components/shared/GameFitLogo";
import ProgressLineChart from "../components/analytics/ProgressLineChart";

export default function Profile() {
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});

  const { data: user, isLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      setEditData({
        full_name: currentUser.full_name,
        fitness_goal: currentUser.fitness_goal,
        age: currentUser.age,
        height: currentUser.height,
        weight: currentUser.weight,
        gender: currentUser.gender
      });
      return currentUser;
    }
  });

  const { data: allWorkouts } = useQuery({
    queryKey: ['allUserWorkouts'],
    queryFn: () => base44.entities.Workout.filter({ created_by: user?.email }),
    enabled: !!user,
    initialData: []
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
      setIsEditing(false);
    }
  });

  const handleSave = () => {
    updateProfileMutation.mutate(editData);
  };

  // Analytics Data
  const getXPProgressData = () => {
    const data = [];
    for (let i = 29; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayWorkouts = allWorkouts.filter(w => {
        const workoutDate = new Date(w.created_date);
        return format(workoutDate, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd');
      });
      
      const totalXP = dayWorkouts.reduce((sum, w) => sum + (w.xp_earned || 0), 0);
      data.push({
        name: format(date, 'MMM d'),
        value: totalXP
      });
    }
    return data;
  };

  const getPersonalRecords = () => {
    if (allWorkouts.length === 0) return null;

    const longestWorkout = allWorkouts.reduce((max, w) => w.duration > max.duration ? w : max);
    const mostXPWorkout = allWorkouts.reduce((max, w) => w.xp_earned > max.xp_earned ? w : max);
    const totalWorkouts = allWorkouts.length;
    const totalDuration = allWorkouts.reduce((sum, w) => sum + w.duration, 0);

    return {
      longestWorkout,
      mostXPWorkout,
      totalWorkouts,
      totalDuration,
      avgDuration: Math.round(totalDuration / totalWorkouts)
    };
  };

  const records = getPersonalRecords();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="neuro-card p-8">
          <p className="text-lg">Loading profile...</p>
        </div>
      </div>
    );
  }

  const fitnessGoals = ["Build Muscle", "Lose Weight", "Improve Endurance", "General Fitness", "Flexibility"];
  const genders = ["Male", "Female", "Non-binary", "Prefer not to say"];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="neuro-card p-6">
        <GameFitLogo size="default" />
      </div>

      <div className="neuro-card p-8">
        <div className="flex flex-col md:flex-row items-start gap-8">
          <div className="flex-shrink-0">
            <AvatarDisplay user={user} />
            <div className="mt-4 text-center">
              <div className="neuro-card px-4 py-2 inline-flex items-center gap-2">
                <Trophy className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
                <span className="font-bold text-lg">Level {user?.level || 1}</span>
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">{user?.full_name || 'Warrior'}</h1>
                <p style={{ color: 'var(--text-secondary)' }}>{user?.email}</p>
              </div>
              {!isEditing ? (
                <button onClick={() => setIsEditing(true)} className="neuro-button p-3">
                  <Edit2 className="w-5 h-5" />
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={handleSave}
                    disabled={updateProfileMutation.isPending}
                    className="neuro-button-accent px-4 py-2 text-white font-semibold rounded-xl flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save
                  </button>
                  <button onClick={() => setIsEditing(false)} className="neuro-button p-2">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>

            {!isEditing ? (
              <div className="grid grid-cols-2 gap-4">
                <div className="neuro-card-inset p-4 rounded-xl">
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Fitness Goal</p>
                  <p className="font-semibold text-lg">{user?.fitness_goal || 'Not set'}</p>
                </div>
                <div className="neuro-card-inset p-4 rounded-xl">
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Age</p>
                  <p className="font-semibold text-lg">{user?.age || 'N/A'}</p>
                </div>
                <div className="neuro-card-inset p-4 rounded-xl">
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Height</p>
                  <p className="font-semibold text-lg">{user?.height ? `${user.height} cm` : 'N/A'}</p>
                </div>
                <div className="neuro-card-inset p-4 rounded-xl">
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Weight</p>
                  <p className="font-semibold text-lg">{user?.weight ? `${user.weight} kg` : 'N/A'}</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Full Name</label>
                  <div className="neuro-card-inset p-3 rounded-xl">
                    <input
                      type="text"
                      value={editData.full_name || ''}
                      onChange={(e) => setEditData({ ...editData, full_name: e.target.value })}
                      className="w-full bg-transparent outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Fitness Goal</label>
                  <div className="neuro-card-inset p-1 rounded-xl">
                    <select
                      value={editData.fitness_goal || ''}
                      onChange={(e) => setEditData({ ...editData, fitness_goal: e.target.value })}
                      className="w-full px-3 py-2 bg-transparent outline-none"
                    >
                      {fitnessGoals.map((goal) => (
                        <option key={goal} value={goal}>{goal}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Age</label>
                    <div className="neuro-card-inset p-3 rounded-xl">
                      <input
                        type="number"
                        value={editData.age || ''}
                        onChange={(e) => setEditData({ ...editData, age: parseInt(e.target.value) || '' })}
                        className="w-full bg-transparent outline-none"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Gender</label>
                    <div className="neuro-card-inset p-1 rounded-xl">
                      <select
                        value={editData.gender || ''}
                        onChange={(e) => setEditData({ ...editData, gender: e.target.value })}
                        className="w-full px-3 py-2 bg-transparent outline-none"
                      >
                        {genders.map((g) => (
                          <option key={g} value={g}>{g}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Height (cm)</label>
                    <div className="neuro-card-inset p-3 rounded-xl">
                      <input
                        type="number"
                        value={editData.height || ''}
                        onChange={(e) => setEditData({ ...editData, height: parseInt(e.target.value) || '' })}
                        className="w-full bg-transparent outline-none"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Weight (kg)</label>
                    <div className="neuro-card-inset p-3 rounded-xl">
                      <input
                        type="number"
                        value={editData.weight || ''}
                        onChange={(e) => setEditData({ ...editData, weight: parseInt(e.target.value) || '' })}
                        className="w-full bg-transparent outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="neuro-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Total XP</span>
          </div>
          <p className="text-3xl font-bold text-gradient">{user?.total_xp || 0}</p>
        </div>
        <div className="neuro-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <Flame className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Best Streak</span>
          </div>
          <p className="text-3xl font-bold" style={{ color: 'var(--accent-red)' }}>
            {user?.best_streak || 0}
          </p>
        </div>
        <div className="neuro-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-5 h-5" style={{ color: '#3b82f6' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Current Streak</span>
          </div>
          <p className="text-3xl font-bold" style={{ color: '#3b82f6' }}>
            {user?.current_streak || 0}
          </p>
        </div>
        <div className="neuro-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <Award className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Coins</span>
          </div>
          <p className="text-3xl font-bold" style={{ color: 'var(--accent-yellow)' }}>
            {user?.coins || 0}
          </p>
        </div>
      </div>

      {/* XP Progress Chart */}
      <div className="neuro-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
          <h3 className="font-semibold">30-Day XP Progress</h3>
        </div>
        <ProgressLineChart data={getXPProgressData()} />
      </div>

      {/* Personal Records */}
      {records && (
        <div className="neuro-card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
            <h3 className="font-semibold">Personal Records</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="neuro-card-inset p-4 rounded-xl text-center">
              <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Total Workouts</p>
              <p className="text-2xl font-bold text-gradient">{records.totalWorkouts}</p>
            </div>
            <div className="neuro-card-inset p-4 rounded-xl text-center">
              <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Avg Duration</p>
              <p className="text-2xl font-bold" style={{ color: 'var(--accent-red)' }}>{records.avgDuration} min</p>
            </div>
            <div className="neuro-card-inset p-4 rounded-xl text-center">
              <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Longest Workout</p>
              <p className="text-2xl font-bold" style={{ color: '#3b82f6' }}>{records.longestWorkout.duration} min</p>
              <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{records.longestWorkout.exercise_type}</p>
            </div>
            <div className="neuro-card-inset p-4 rounded-xl text-center">
              <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>Best XP Gain</p>
              <p className="text-2xl font-bold" style={{ color: 'var(--accent-yellow)' }}>{records.mostXPWorkout.xp_earned} XP</p>
              <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{records.mostXPWorkout.exercise_type}</p>
            </div>
          </div>
        </div>
      )}

      <AvatarCustomizer user={user} />
    </div>
  );
}
