import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ShoppingBag, Award, Lock, Check, Sparkles, Tag } from "lucide-react";

export default function Marketplace() {
  const queryClient = useQueryClient();
  const [selectedReward, setSelectedReward] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: rewards, isLoading } = useQuery({
    queryKey: ['rewards'],
    queryFn: () => base44.entities.Reward.list(),
    initialData: []
  });

  const redeemRewardMutation = useMutation({
    mutationFn: async (reward) => {
      if ((user?.coins || 0) < reward.cost) {
        throw new Error("Insufficient coins");
      }
      
      await base44.auth.updateMe({
        coins: user.coins - reward.cost
      });

      if (reward.reward_type === "Avatar Item") {
        await base44.entities.AvatarItem.create({
          item_name: reward.title,
          item_type: "Accessory",
          unlocked_at_level: 0,
          user_id: user.id,
          is_equipped: false,
          rarity: "Rare"
        });
      }

      return reward;
    },
    onSuccess: (reward) => {
      queryClient.invalidateQueries(['currentUser']);
      alert(`🎉 Successfully redeemed: ${reward.title}!${reward.redemption_code ? `\n\nYour code: ${reward.redemption_code}` : ''}`);
      setSelectedReward(null);
    },
    onError: (error) => {
      alert(error.message || "Failed to redeem reward. Please try again.");
    }
  });

  const handleRedeem = (reward) => {
    if (reward.is_premium_only && user?.subscription_tier !== "Premium") {
      alert("This reward is only available for Premium members. Upgrade to access!");
      return;
    }
    
    if ((user?.coins || 0) < reward.cost) {
      alert(`You need ${reward.cost - (user?.coins || 0)} more coins to redeem this reward!`);
      return;
    }

    if (window.confirm(`Redeem "${reward.title}" for ${reward.cost} coins?`)) {
      redeemRewardMutation.mutate(reward);
    }
  };

  const rewardTypes = ["All", "Avatar Item", "Discount Code", "Partner Offer"];
  const [filterType, setFilterType] = useState("All");

  const filteredRewards = filterType === "All" 
    ? rewards 
    : rewards.filter(r => r.reward_type === filterType);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="neuro-card p-8">
          <p className="text-lg">Loading marketplace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="neuro-card p-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="neuro-card p-4">
              <ShoppingBag className="w-8 h-8" style={{ color: 'var(--accent-yellow)' }} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gradient">Reward Marketplace</h1>
              <p style={{ color: 'var(--text-secondary)' }}>
                Spend your hard-earned coins on awesome rewards
              </p>
            </div>
          </div>
          
          <div className="neuro-card p-6">
            <div className="flex items-center gap-3">
              <Award className="w-6 h-6" style={{ color: 'var(--accent-yellow)' }} />
              <div>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Your Balance</p>
                <p className="text-3xl font-bold" style={{ color: 'var(--accent-yellow)' }}>
                  {user?.coins || 0}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="neuro-card p-4">
        <div className="flex flex-wrap gap-2">
          {rewardTypes.map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`neuro-button px-4 py-2 ${
                filterType === type ? 'nav-item-active' : ''
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Rewards Grid */}
      {filteredRewards.length === 0 ? (
        <div className="neuro-card p-12 text-center">
          <ShoppingBag className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-secondary)' }} />
          <p style={{ color: 'var(--text-secondary)' }}>
            No rewards available yet. Check back soon!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRewards.map((reward) => {
            const canAfford = (user?.coins || 0) >= reward.cost;
            const isLocked = reward.is_premium_only && user?.subscription_tier !== "Premium";

            return (
              <div key={reward.id} className="neuro-card p-6 flex flex-col">
                {reward.image_url && (
                  <div className="neuro-card-inset rounded-xl overflow-hidden mb-4 h-40 flex items-center justify-center">
                    <img 
                      src={reward.image_url} 
                      alt={reward.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-bold text-lg">{reward.title}</h3>
                    {isLocked && (
                      <Lock className="w-5 h-5" style={{ color: 'var(--text-secondary)' }} />
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 mb-3">
                    <span 
                      className="px-3 py-1 rounded-full text-xs font-semibold"
                      style={{ 
                        background: 'var(--accent-yellow)20',
                        color: 'var(--accent-yellow)'
                      }}
                    >
                      <Tag className="w-3 h-3 inline mr-1" />
                      {reward.reward_type}
                    </span>
                    {reward.is_premium_only && (
                      <span 
                        className="px-3 py-1 rounded-full text-xs font-semibold"
                        style={{ 
                          background: '#8b5cf620',
                          color: '#8b5cf6'
                        }}
                      >
                        <Sparkles className="w-3 h-3 inline mr-1" />
                        Premium
                      </span>
                    )}
                  </div>

                  <p style={{ color: 'var(--text-secondary)' }} className="text-sm mb-4">
                    {reward.description}
                  </p>

                  {reward.stock > 0 && (
                    <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>
                      {reward.stock} remaining
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between gap-3 mt-4">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
                    <span className="text-2xl font-bold" style={{ color: 'var(--accent-yellow)' }}>
                      {reward.cost}
                    </span>
                  </div>
                  
                  <button
                    onClick={() => handleRedeem(reward)}
                    disabled={!canAfford || isLocked || redeemRewardMutation.isPending}
                    className={`${
                      canAfford && !isLocked
                        ? 'neuro-button-accent text-white'
                        : 'neuro-button'
                    } px-6 py-2 font-semibold rounded-xl flex items-center gap-2`}
                    style={!canAfford || isLocked ? { opacity: 0.5 } : {}}
                  >
                    {isLocked ? (
                      <>
                        <Lock className="w-4 h-4" />
                        Locked
                      </>
                    ) : canAfford ? (
                      <>
                        <Check className="w-4 h-4" />
                        Redeem
                      </>
                    ) : (
                      <>Not Enough Coins</>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info Card */}
      <div className="neuro-card p-6">
        <h3 className="font-bold mb-2 flex items-center gap-2">
          <Sparkles className="w-5 h-5" style={{ color: 'var(--accent-yellow)' }} />
          How to Earn Coins
        </h3>
        <ul className="space-y-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
          <li>• Complete workouts to earn XP (10 coins per 100 XP)</li>
          <li>• Level up your avatar for bonus coins</li>
          <li>• Maintain daily workout streaks</li>
          <li>• Upgrade to Premium for exclusive rewards</li>
        </ul>
      </div>
    </div>
  );
}