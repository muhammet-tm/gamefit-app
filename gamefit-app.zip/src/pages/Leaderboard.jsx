import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Medal, Award, Crown, TrendingUp } from "lucide-react";

export default function Leaderboard() {
  const [timeFilter, setTimeFilter] = useState("all");

  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    retry: false
  });

  const { data: allUsers, isLoading } = useQuery({
    queryKey: ['leaderboard', timeFilter],
    queryFn: async () => {
      const users = await base44.entities.User.list('-total_xp', 100);
      return users.filter(u => (u.total_xp || 0) > 0);
    },
    initialData: []
  });

  const getRankIcon = (index) => {
    if (index === 0) return <Crown className="w-6 h-6" style={{ color: '#ffd700' }} />;
    if (index === 1) return <Medal className="w-6 h-6" style={{ color: '#c0c0c0' }} />;
    if (index === 2) return <Medal className="w-6 h-6" style={{ color: '#cd7f32' }} />;
    return <div className="w-6 text-center font-bold" style={{ color: 'var(--text-secondary)' }}>#{index + 1}</div>;
  };

  const getRankBg = (index) => {
    if (index === 0) return 'linear-gradient(135deg, #ffd700, #ffed4e)';
    if (index === 1) return 'linear-gradient(135deg, #c0c0c0, #e8e8e8)';
    if (index === 2) return 'linear-gradient(135deg, #cd7f32, #f5a962)';
    return 'var(--bg-base)';
  };

  const currentUserRank = currentUser ? allUsers.findIndex(u => u.email === currentUser.email) : -1;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="neuro-card p-8">
          <p className="text-lg">Loading leaderboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="neuro-card p-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="neuro-card p-4">
            <Trophy className="w-8 h-8" style={{ color: 'var(--accent-yellow)' }} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gradient">Global Leaderboard</h1>
            <p style={{ color: 'var(--text-secondary)' }}>
              Compete with warriors worldwide
            </p>
          </div>
        </div>

        {currentUser && currentUserRank >= 0 && (
          <div className="neuro-card-inset p-4 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
                <div>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Your Rank</p>
                  <p className="text-xl font-bold">#{currentUserRank + 1}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Your XP</p>
                <p className="text-xl font-bold text-gradient">{currentUser?.total_xp || 0}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {allUsers.length >= 3 && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="neuro-card p-6 flex flex-col items-center pt-12">
            <Medal className="w-12 h-12 mb-3" style={{ color: '#c0c0c0' }} />
            <div className="w-16 h-16 rounded-full neuro-card flex items-center justify-center mb-2">
              <span className="text-2xl font-bold">2</span>
            </div>
            <p className="font-bold text-center mb-1">{allUsers[1]?.full_name}</p>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Level {allUsers[1]?.level || 1}
            </p>
            <p className="text-lg font-bold text-gradient mt-2">
              {allUsers[1]?.total_xp || 0} XP
            </p>
          </div>

          <div className="neuro-card p-6 flex flex-col items-center">
            <Crown className="w-16 h-16 mb-3" style={{ color: '#ffd700' }} />
            <div className="w-20 h-20 rounded-full neuro-card flex items-center justify-center mb-2">
              <span className="text-3xl font-bold">1</span>
            </div>
            <p className="font-bold text-center mb-1 text-lg">{allUsers[0]?.full_name}</p>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Level {allUsers[0]?.level || 1}
            </p>
            <p className="text-2xl font-bold text-gradient mt-2">
              {allUsers[0]?.total_xp || 0} XP
            </p>
          </div>

          <div className="neuro-card p-6 flex flex-col items-center pt-12">
            <Medal className="w-12 h-12 mb-3" style={{ color: '#cd7f32' }} />
            <div className="w-16 h-16 rounded-full neuro-card flex items-center justify-center mb-2">
              <span className="text-2xl font-bold">3</span>
            </div>
            <p className="font-bold text-center mb-1">{allUsers[2]?.full_name}</p>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Level {allUsers[2]?.level || 1}
            </p>
            <p className="text-lg font-bold text-gradient mt-2">
              {allUsers[2]?.total_xp || 0} XP
            </p>
          </div>
        </div>
      )}

      <div className="neuro-card p-6">
        <h2 className="text-xl font-bold mb-4">All Rankings</h2>
        <div className="space-y-2">
          {allUsers.map((user, index) => (
            <div
              key={user.id}
              className={`p-4 rounded-xl transition-all ${
                currentUser && user.email === currentUser.email
                  ? 'neuro-card-inset'
                  : 'neuro-card'
              }`}
              style={index < 3 ? { background: getRankBg(index) } : {}}
            >
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  {getRankIcon(index)}
                  <div className="flex-1 min-w-0">
                    <p className="font-bold truncate">
                      {user.full_name}
                      {currentUser && user.email === currentUser.email && (
                        <span className="ml-2 text-sm font-normal" style={{ color: 'var(--accent-red)' }}>
                          (You)
                        </span>
                      )}
                    </p>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                      Level {user.level || 1} • {user.avatar_type || 'Warrior'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-gradient">{user.total_xp || 0}</p>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>XP</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}