import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import WorkoutLog from "./WorkoutLog";

import Profile from "./Profile";

import Leaderboard from "./Leaderboard";

import AICoach from "./AICoach";

import Marketplace from "./Marketplace";

import Settings from "./Settings";

import FitSistersCommunity from "./FitSistersCommunity";

import Achievements from "./Achievements";

import MyPlan from "./MyPlan";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    WorkoutLog: WorkoutLog,
    
    Profile: Profile,
    
    Leaderboard: Leaderboard,
    
    AICoach: AICoach,
    
    Marketplace: Marketplace,
    
    Settings: Settings,
    
    FitSistersCommunity: FitSistersCommunity,
    
    Achievements: Achievements,
    
    MyPlan: MyPlan,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/WorkoutLog" element={<WorkoutLog />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Leaderboard" element={<Leaderboard />} />
                
                <Route path="/AICoach" element={<AICoach />} />
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/FitSistersCommunity" element={<FitSistersCommunity />} />
                
                <Route path="/Achievements" element={<Achievements />} />
                
                <Route path="/MyPlan" element={<MyPlan />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}