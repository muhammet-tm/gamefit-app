
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Heart, MessageCircle, Send, Image as ImageIcon, Users, TrendingUp, Sparkles } from "lucide-react";
import { format } from "date-fns";

import GameFitLogo from "../components/shared/GameFitLogo";
import CommunityPostCard from "../components/community/CommunityPostCard";
import CreatePostForm from "../components/community/CreatePostForm";

export default function FitSistersCommunity() {
  const queryClient = useQueryClient();
  const [showCreatePost, setShowCreatePost] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: posts, isLoading } = useQuery({
    queryKey: ['communityPosts'],
    queryFn: () => base44.entities.CommunityPost.filter({ community: "FitSisters" }, '-created_date', 50),
    initialData: []
  });

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.CommunityPost.create({
      ...postData,
      community: "FitSisters"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['communityPosts']);
      setShowCreatePost(false);
    }
  });

  if (!user?.join_fitsister) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="neuro-card p-6">
          <GameFitLogo size="default" />
        </div>
        <div className="neuro-card p-12 text-center">
          <Users className="w-16 h-16 mx-auto mb-4" style={{ color: '#ec4899' }} />
          <h2 className="text-2xl font-bold mb-4">Join FitSisters Community</h2>
          <p style={{ color: 'var(--text-secondary)' }} className="mb-6">
            A supportive space for women to share their fitness journey, ask questions, and motivate each other.
          </p>
          <button
            onClick={async () => {
              await base44.auth.updateMe({ join_fitsister: true });
              queryClient.invalidateQueries(['currentUser']);
            }}
            className="neuro-button-accent px-8 py-4 text-white font-bold rounded-xl"
          >
            Join FitSisters
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="neuro-card p-6">
        <GameFitLogo size="default" />
      </div>

      <div className="neuro-card p-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="neuro-card p-4" style={{ background: 'linear-gradient(135deg, #ec4899, #f472b6)' }}>
            <Users className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">FitSisters Community</h1>
            <p style={{ color: 'var(--text-secondary)' }}>
              Empowering women through fitness and support
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="neuro-card p-4 text-center">
            <Users className="w-6 h-6 mx-auto mb-2" style={{ color: '#ec4899' }} />
            <p className="text-2xl font-bold">{posts.length > 0 ? new Set(posts.map(p => p.created_by)).size : 0}</p>
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Members</p>
          </div>
          <div className="neuro-card p-4 text-center">
            <MessageCircle className="w-6 h-6 mx-auto mb-2" style={{ color: '#ec4899' }} />
            <p className="text-2xl font-bold">{posts.length}</p>
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Posts</p>
          </div>
          <div className="neuro-card p-4 text-center">
            <Heart className="w-6 h-6 mx-auto mb-2" style={{ color: '#ec4899' }} />
            <p className="text-2xl font-bold">{posts.reduce((sum, p) => sum + p.likes, 0)}</p>
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Likes</p>
          </div>
        </div>

        <button
          onClick={() => setShowCreatePost(!showCreatePost)}
          className="neuro-button-accent w-full py-4 text-white font-bold rounded-xl flex items-center justify-center gap-2 mb-6"
        >
          <Sparkles className="w-5 h-5" />
          Share Your Progress
        </button>
      </div>

      {showCreatePost && (
        <CreatePostForm
          onSubmit={(data) => createPostMutation.mutate(data)}
          onCancel={() => setShowCreatePost(false)}
          isSubmitting={createPostMutation.isPending}
        />
      )}

      <div className="space-y-4">
        {isLoading ? (
          <div className="neuro-card p-8 text-center">
            <p style={{ color: 'var(--text-secondary)' }}>Loading posts...</p>
          </div>
        ) : posts.length === 0 ? (
          <div className="neuro-card p-12 text-center">
            <MessageCircle className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-secondary)' }} />
            <p style={{ color: 'var(--text-secondary)' }}>
              No posts yet. Be the first to share!
            </p>
          </div>
        ) : (
          posts.map(post => (
            <CommunityPostCard key={post.id} post={post} currentUser={user} />
          ))
        )}
      </div>
    </div>
  );
}
