import { base44 } from './base44Client';


export const Workout = base44.entities.Workout;

export const Reward = base44.entities.Reward;

export const AvatarItem = base44.entities.AvatarItem;

export const CommunityPost = base44.entities.CommunityPost;

export const CommunityComment = base44.entities.CommunityComment;

export const PostLike = base44.entities.PostLike;

export const Achievement = base44.entities.Achievement;

export const UserAchievement = base44.entities.UserAchievement;

export const DailyChallenge = base44.entities.DailyChallenge;

export const ChallengeCompletion = base44.entities.ChallengeCompletion;

export const WorkoutPlan = base44.entities.WorkoutPlan;

export const WorkoutPlanFeedback = base44.entities.WorkoutPlanFeedback;



// auth sdk:
export const User = base44.auth;