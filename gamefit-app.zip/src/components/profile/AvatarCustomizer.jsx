import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Palette, Sparkles, Crown, Lock } from "lucide-react";

export default function AvatarCustomizer({ user }) {
  const queryClient = useQueryClient();
  const [selectedType, setSelectedType] = useState(user?.avatar_type || "Warrior");
  const [selectedColor, setSelectedColor] = useState(user?.avatar_color || "#c41e3a");

  const isPremium = user?.subscription_tier === "Premium";

  const avatarTypes = [
    { name: "Warrior", premium: false },
    { name: "Athlete", premium: false },
    { name: "Robot", premium: false },
    { name: "Ninja", premium: true },
    { name: "Explorer", premium: true }
  ];

  const colorOptions = [
    { name: "Crimson", value: "#c41e3a", premium: false },
    { name: "Electric Blue", value: "#3b82f6", premium: false },
    { name: "Emerald", value: "#10b981", premium: false },
    { name: "Purple", value: "#8b5cf6", premium: true },
    { name: "Orange", value: "#f97316", premium: true },
    { name: "Pink", value: "#ec4899", premium: true }
  ];

  const updateAvatarMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
    }
  });

  const handleApply = () => {
    updateAvatarMutation.mutate({
      avatar_type: selectedType,
      avatar_color: selectedColor
    });
  };

  const handleSelection = (item, type) => {
    if (item.premium && !isPremium) {
      alert("This is a Premium feature. Upgrade to unlock!");
      return;
    }
    if (type === "avatar") {
      setSelectedType(item.name);
    } else {
      setSelectedColor(item.value);
    }
  };

  return (
    <div className="neuro-card p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="neuro-card p-3">
          <Sparkles className="w-6 h-6" style={{ color: 'var(--accent-yellow)' }} />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Customize Your Avatar</h2>
          <p style={{ color: 'var(--text-secondary)' }} className="text-sm">
            Express yourself! {!isPremium && "Upgrade for exclusive options."}
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Avatar Type */}
        <div>
          <h3 className="font-semibold mb-3">Avatar Character</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {avatarTypes.map((type) => (
              <button
                key={type.name}
                onClick={() => handleSelection(type, "avatar")}
                disabled={type.premium && !isPremium}
                className={`neuro-button p-4 text-center relative ${
                  selectedType === type.name ? 'nav-item-active' : ''
                } ${type.premium && !isPremium ? 'opacity-50' : ''}`}
              >
                {type.premium && (
                  <div className="absolute top-2 right-2">
                    {isPremium ? (
                      <Crown className="w-4 h-4" style={{ color: 'var(--accent-yellow)' }} />
                    ) : (
                      <Lock className="w-4 h-4" style={{ color: 'var(--text-secondary)' }} />
                    )}
                  </div>
                )}
                <p className="font-semibold">{type.name}</p>
                {type.premium && !isPremium && (
                  <p className="text-xs mt-1" style={{ color: 'var(--accent-yellow)' }}>Premium</p>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Color Selection */}
        <div>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Primary Color
          </h3>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {colorOptions.map((color) => (
              <button
                key={color.value}
                onClick={() => handleSelection(color, "color")}
                disabled={color.premium && !isPremium}
                className={`neuro-button p-4 flex flex-col items-center gap-2 relative ${
                  selectedColor === color.value ? 'nav-item-active' : ''
                } ${color.premium && !isPremium ? 'opacity-50' : ''}`}
              >
                {color.premium && (
                  <div className="absolute top-2 right-2">
                    {isPremium ? (
                      <Crown className="w-3 h-3" style={{ color: 'var(--accent-yellow)' }} />
                    ) : (
                      <Lock className="w-3 h-3" style={{ color: 'var(--text-secondary)' }} />
                    )}
                  </div>
                )}
                <div
                  className="w-8 h-8 rounded-full"
                  style={{ 
                    background: color.value,
                    boxShadow: selectedColor === color.value ? `0 0 20px ${color.value}` : 'none'
                  }}
                />
                <p className="text-xs font-medium">{color.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Apply Button */}
        <button
          onClick={handleApply}
          disabled={updateAvatarMutation.isPending}
          className="neuro-button-accent w-full py-4 text-white font-bold text-lg rounded-xl"
        >
          {updateAvatarMutation.isPending ? 'Applying...' : 'Apply Changes'}
        </button>

        {(selectedType !== user?.avatar_type || selectedColor !== user?.avatar_color) && (
          <p className="text-center text-sm" style={{ color: 'var(--text-secondary)' }}>
            You have unsaved changes. Click "Apply Changes" to save.
          </p>
        )}
      </div>
    </div>
  );
}