import React from "react";

export default function StatsCard({ icon: Icon, label, value, color }) {
  return (
    <div className="neuro-card p-6">
      <div className="flex items-center gap-4">
        <div 
          className="neuro-card p-3 flex-shrink-0"
          style={{ background: `${color}15` }}
        >
          <Icon className="w-6 h-6" style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>
            {label}
          </p>
          <p className="text-2xl font-bold truncate">
            {value}
          </p>
        </div>
      </div>
    </div>
  );
}