import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Dumbbell, Brain, ShoppingBag, Trophy } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      title: "Log Workout",
      description: "Earn XP now",
      icon: Dumbbell,
      url: createPageUrl("WorkoutLog"),
      color: "var(--accent-red)"
    },
    {
      title: "AI Coach",
      description: "Get guidance",
      icon: Brain,
      url: createPageUrl("AICoach"),
      color: "#8b5cf6"
    },
    {
      title: "Marketplace",
      description: "Spend coins",
      icon: ShoppingBag,
      url: createPageUrl("Marketplace"),
      color: "var(--accent-yellow)"
    },
    {
      title: "Leaderboard",
      description: "See rankings",
      icon: Trophy,
      url: createPageUrl("Leaderboard"),
      color: "#3b82f6"
    }
  ];

  return (
    <div className="neuro-card p-6">
      <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.title}
              to={action.url}
              className="neuro-button p-4 flex flex-col items-center gap-2 text-center hover:scale-105 transition-transform"
            >
              <div 
                className="neuro-card p-3"
                style={{ background: `${action.color}15` }}
              >
                <Icon className="w-6 h-6" style={{ color: action.color }} />
              </div>
              <div>
                <p className="font-semibold text-sm">{action.title}</p>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  {action.description}
                </p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}