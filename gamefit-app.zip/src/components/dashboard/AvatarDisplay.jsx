import React, { useRef, useEffect } from "react";
import * as THREE from "three";

export default function AvatarDisplay({ user }) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const avatarColor = user?.avatar_color || "#c41e3a";
  const level = user?.level || 1;

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 1000);
    camera.position.z = 6;

    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true 
    });
    renderer.setSize(200, 200);
    renderer.setClearColor(0x000000, 0);
    rendererRef.current = renderer;
    mountRef.current.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0xffffff, 0.8);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    const group = new THREE.Group();

    const headGeometry = new THREE.SphereGeometry(0.7, 32, 32);
    const headMaterial = new THREE.MeshPhongMaterial({ 
      color: 0xffdbac,
      shininess: 30
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 1.5;
    group.add(head);

    const eyeGeometry = new THREE.SphereGeometry(0.12, 16, 16);
    const eyeMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-0.25, 1.6, 0.5);
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(0.25, 1.6, 0.5);
    group.add(leftEye, rightEye);

    const smileCurve = new THREE.EllipseCurve(
      0, 1.3, 0.3, 0.15, 0, Math.PI, false, 0
    );
    const smilePoints = smileCurve.getPoints(50);
    const smileGeometry = new THREE.BufferGeometry().setFromPoints(smilePoints);
    const smileMaterial = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    const smile = new THREE.Line(smileGeometry, smileMaterial);
    smile.position.z = 0.5;
    group.add(smile);

    const bodyGeometry = new THREE.CapsuleGeometry(0.5, 1, 4, 8);
    const bodyMaterial = new THREE.MeshPhongMaterial({ 
      color: avatarColor,
      shininess: 30
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = 0.2;
    group.add(body);

    const armGeometry = new THREE.CapsuleGeometry(0.15, 0.8, 4, 8);
    const armMaterial = new THREE.MeshPhongMaterial({ color: avatarColor });
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-0.7, 0.3, 0);
    leftArm.rotation.z = 0.3;
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(0.7, 0.3, 0);
    rightArm.rotation.z = -0.3;
    group.add(leftArm, rightArm);

    const legGeometry = new THREE.CapsuleGeometry(0.18, 0.9, 4, 8);
    const legMaterial = new THREE.MeshPhongMaterial({ color: 0x2d2d2d });
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.25, -0.8, 0);
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.25, -0.8, 0);
    group.add(leftLeg, rightLeg);

    if (level >= 5) {
      const headbandGeometry = new THREE.TorusGeometry(0.7, 0.08, 8, 32);
      const headbandMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xffa500,
        shininess: 50
      });
      const headband = new THREE.Mesh(headbandGeometry, headbandMaterial);
      headband.rotation.x = Math.PI / 2;
      headband.position.y = 1.8;
      group.add(headband);
    }

    if (level >= 10) {
      for (let i = 0; i < 3; i++) {
        const auraGeometry = new THREE.TorusGeometry(1.5 + i * 0.3, 0.05, 16, 100);
        const auraMaterial = new THREE.MeshBasicMaterial({ 
          color: 0xffa500,
          transparent: true,
          opacity: 0.2 - i * 0.05
        });
        const aura = new THREE.Mesh(auraGeometry, auraMaterial);
        aura.rotation.x = Math.PI / 2;
        aura.position.y = 0.5;
        group.add(aura);
      }
    }

    if (level >= 15) {
      const crownGeometry = new THREE.ConeGeometry(0.3, 0.4, 6);
      const crownMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xffd700,
        shininess: 100
      });
      const crown = new THREE.Mesh(crownGeometry, crownMaterial);
      crown.position.y = 2.3;
      group.add(crown);
    }

    scene.add(group);
    group.position.y = -0.5;

    let animationId;
    let time = 0;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      time += 0.01;
      
      group.rotation.y = Math.sin(time * 0.5) * 0.3;
      group.position.y = -0.5 + Math.sin(time) * 0.1;
      body.scale.y = 1 + Math.sin(time * 2) * 0.05;
      
      if (Math.random() > 0.98) {
        leftEye.scale.y = 0.1;
        rightEye.scale.y = 0.1;
        setTimeout(() => {
          leftEye.scale.y = 1;
          rightEye.scale.y = 1;
        }, 100);
      }

      if (level >= 10) {
        group.children.forEach(child => {
          if (child.geometry instanceof THREE.TorusGeometry && child.material.transparent) {
            child.rotation.z += 0.005;
            child.material.opacity = 0.2 + Math.sin(time * 2) * 0.1;
          }
        });
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationId);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [avatarColor, level]);

  return (
    <div className="neuro-card p-4 flex flex-col items-center">
      <div ref={mountRef} className="rounded-lg overflow-hidden" />
      <p className="text-sm font-semibold mt-2">{user?.avatar_type || "Warrior"}</p>
      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
        Lv. {level}
      </p>
    </div>
  );
}