import React from "react";
import { format } from "date-fns";
import { Dumbbell, Clock, Zap, TrendingUp } from "lucide-react";

export default function RecentWorkouts({ workouts, isLoading }) {
  const intensityColors = {
    Light: "#4ade80",
    Moderate: "#fbbf24",
    Intense: "#ef4444"
  };

  if (isLoading) {
    return (
      <div className="neuro-card p-6">
        <h2 className="text-xl font-bold mb-4">Recent Workouts</h2>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="neuro-card-inset p-4 animate-pulse">
              <div className="h-4 bg-gray-300 rounded w-1/3 mb-2"></div>
              <div className="h-3 bg-gray-300 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!workouts || workouts.length === 0) {
    return (
      <div className="neuro-card p-6">
        <h2 className="text-xl font-bold mb-4">Recent Workouts</h2>
        <div className="neuro-card-inset p-8 text-center">
          <Dumbbell className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--text-secondary)' }} />
          <p style={{ color: 'var(--text-secondary)' }}>
            No workouts logged yet. Start your fitness journey!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="neuro-card p-6">
      <h2 className="text-xl font-bold mb-4">Recent Workouts</h2>
      <div className="space-y-3">
        {workouts.map((workout) => (
          <div key={workout.id} className="neuro-card-inset p-4">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Dumbbell className="w-4 h-4" style={{ color: 'var(--accent-red)' }} />
                  <h3 className="font-semibold">{workout.exercise_type}</h3>
                  <span 
                    className="px-2 py-0.5 rounded-full text-xs font-medium"
                    style={{ 
                      background: `${intensityColors[workout.intensity]}20`,
                      color: intensityColors[workout.intensity]
                    }}
                  >
                    {workout.intensity}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-sm" style={{ color: 'var(--text-secondary)' }}>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {workout.duration} min
                  </span>
                  <span className="flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    +{workout.xp_earned} XP
                  </span>
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {workout.calories_burned || 0} cal
                  </span>
                </div>
                {workout.notes && (
                  <p className="text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>
                    {workout.notes}
                  </p>
                )}
              </div>
              <div className="text-right text-xs" style={{ color: 'var(--text-secondary)' }}>
                {format(new Date(workout.created_date), 'MMM d')}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}