import React from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from "date-fns";
import { Flame } from "lucide-react";

export default function StreakCalendar({ workoutDates }) {
  const today = new Date();
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const hasWorkout = (date) => {
    return workoutDates.some(workoutDate => 
      isSameDay(new Date(workoutDate), date)
    );
  };

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Flame className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
        <h3 className="font-semibold">Workout Calendar</h3>
      </div>
      
      {/* Week day headers */}
      <div className="grid grid-cols-7 gap-2 mb-2">
        {weekDays.map(day => (
          <div key={day} className="text-center text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>
            {day}
          </div>
        ))}
      </div>

      {/* Calendar days */}
      <div className="grid grid-cols-7 gap-2">
        {/* Empty cells for days before month starts */}
        {Array.from({ length: monthStart.getDay() }).map((_, i) => (
          <div key={`empty-${i}`} />
        ))}
        
        {/* Days of month */}
        {daysInMonth.map(date => {
          const hasWorkoutToday = hasWorkout(date);
          const isToday = isSameDay(date, today);
          
          return (
            <div
              key={date.toISOString()}
              className={`
                aspect-square flex items-center justify-center text-sm rounded-lg
                ${hasWorkoutToday ? 'neuro-button-accent text-white font-bold' : 'neuro-card-inset'}
                ${isToday ? 'ring-2 ring-offset-2' : ''}
              `}
              style={isToday ? { ringColor: 'var(--accent-yellow)' } : {}}
            >
              {format(date, 'd')}
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex items-center justify-center gap-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 neuro-button-accent rounded" />
          <span style={{ color: 'var(--text-secondary)' }}>Workout Day</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 neuro-card-inset rounded" />
          <span style={{ color: 'var(--text-secondary)' }}>Rest Day</span>
        </div>
      </div>
    </div>
  );
}