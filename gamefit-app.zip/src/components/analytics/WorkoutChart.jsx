import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

export default function WorkoutChart({ data, type = "xp" }) {
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="neuro-card p-3">
          <p className="font-semibold mb-1">{label}</p>
          <p style={{ color: 'var(--accent-red)' }}>
            {type === "xp" ? `${payload[0].value} XP` : `${payload[0].value} min`}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--accent-red)" stopOpacity={0.8} />
            <stop offset="100%" stopColor="var(--accent-yellow)" stopOpacity={0.8} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--shadow-dark)" opacity={0.1} />
        <XAxis 
          dataKey="name" 
          stroke="var(--text-secondary)" 
          style={{ fontSize: '12px' }}
        />
        <YAxis 
          stroke="var(--text-secondary)" 
          style={{ fontSize: '12px' }}
        />
        <Tooltip content={<CustomTooltip />} />
        <Bar 
          dataKey="value" 
          fill="url(#barGradient)" 
          radius={[10, 10, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}