import React from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function ProgressLineChart({ data }) {
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="neuro-card p-3">
          <p className="font-semibold mb-1">{label}</p>
          <p style={{ color: 'var(--accent-red)' }}>
            XP: {payload[0].value}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height={250}>
      <LineChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
        <defs>
          <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="var(--accent-red)" />
            <stop offset="100%" stopColor="var(--accent-yellow)" />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--shadow-dark)" opacity={0.1} />
        <XAxis 
          dataKey="name" 
          stroke="var(--text-secondary)" 
          style={{ fontSize: '12px' }}
        />
        <YAxis 
          stroke="var(--text-secondary)" 
          style={{ fontSize: '12px' }}
        />
        <Tooltip content={<CustomTooltip />} />
        <Line 
          type="monotone" 
          dataKey="value" 
          stroke="url(#lineGradient)" 
          strokeWidth={3}
          dot={{ fill: 'var(--accent-red)', r: 4 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}