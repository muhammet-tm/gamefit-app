import React, { useState } from "react";
import { X, Image as ImageIcon } from "lucide-react";

export default function CreatePostForm({ onSubmit, onCancel, isSubmitting }) {
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    onSubmit({ content, image_url: imageUrl || undefined });
    setContent("");
    setImageUrl("");
  };

  return (
    <div className="neuro-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-lg">Create Post</h3>
        <button onClick={onCancel} className="neuro-button p-2">
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="neuro-card-inset p-4 rounded-xl">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Share your progress, ask questions, or motivate others..."
            rows="4"
            className="w-full bg-transparent outline-none resize-none"
            required
          />
        </div>

        <div className="neuro-card-inset p-4 rounded-xl">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5" style={{ color: 'var(--text-secondary)' }} />
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="Image URL (optional)"
              className="flex-1 bg-transparent outline-none"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !content.trim()}
          className="neuro-button-accent w-full py-3 text-white font-bold rounded-xl"
        >
          {isSubmitting ? 'Posting...' : 'Post'}
        </button>
      </form>
    </div>
  );
}