import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart, MessageCircle, Send } from "lucide-react";
import { format } from "date-fns";

export default function CommunityPostCard({ post, currentUser }) {
  const queryClient = useQueryClient();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");

  const { data: comments } = useQuery({
    queryKey: ['comments', post.id],
    queryFn: () => base44.entities.CommunityComment.filter({ post_id: post.id }, '-created_date'),
    enabled: showComments,
    initialData: []
  });

  const { data: userLike } = useQuery({
    queryKey: ['postLike', post.id, currentUser?.email],
    queryFn: () => base44.entities.PostLike.filter({ post_id: post.id, user_email: currentUser?.email }),
    initialData: []
  });

  const hasLiked = userLike.length > 0;

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (hasLiked) {
        await base44.entities.PostLike.delete(userLike[0].id);
        await base44.entities.CommunityPost.update(post.id, { likes: post.likes - 1 });
      } else {
        await base44.entities.PostLike.create({ post_id: post.id, user_email: currentUser.email });
        await base44.entities.CommunityPost.update(post.id, { likes: post.likes + 1 });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['communityPosts']);
      queryClient.invalidateQueries(['postLike']);
    }
  });

  const commentMutation = useMutation({
    mutationFn: async (content) => {
      await base44.entities.CommunityComment.create({ post_id: post.id, content });
      await base44.entities.CommunityPost.update(post.id, { comments_count: post.comments_count + 1 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['comments']);
      queryClient.invalidateQueries(['communityPosts']);
      setCommentText("");
    }
  });

  return (
    <div className="neuro-card p-6">
      <div className="flex items-start gap-4 mb-4">
        <div className="neuro-card w-12 h-12 flex items-center justify-center flex-shrink-0">
          <span className="font-bold text-lg">{post.created_by?.charAt(0).toUpperCase()}</span>
        </div>
        <div className="flex-1">
          <h3 className="font-bold">{post.created_by?.split('@')[0]}</h3>
          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
            {format(new Date(post.created_date), 'MMM d, yyyy • h:mm a')}
          </p>
        </div>
      </div>

      <p className="mb-4">{post.content}</p>

      {post.image_url && (
        <div className="neuro-card-inset rounded-xl overflow-hidden mb-4">
          <img src={post.image_url} alt="Post" className="w-full" />
        </div>
      )}

      <div className="flex items-center gap-4 mb-4">
        <button
          onClick={() => likeMutation.mutate()}
          disabled={likeMutation.isPending}
          className="neuro-button px-4 py-2 flex items-center gap-2"
        >
          <Heart 
            className="w-5 h-5" 
            style={{ color: hasLiked ? '#ec4899' : 'var(--text-secondary)' }}
            fill={hasLiked ? '#ec4899' : 'none'}
          />
          <span className="font-semibold">{post.likes}</span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="neuro-button px-4 py-2 flex items-center gap-2"
        >
          <MessageCircle className="w-5 h-5" style={{ color: 'var(--text-secondary)' }} />
          <span className="font-semibold">{post.comments_count}</span>
        </button>
      </div>

      {showComments && (
        <div className="neuro-card-inset p-4 rounded-xl space-y-4">
          {comments.map(comment => (
            <div key={comment.id} className="flex gap-3">
              <div className="neuro-card w-8 h-8 flex items-center justify-center flex-shrink-0 text-sm">
                {comment.created_by?.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">{comment.created_by?.split('@')[0]}</p>
                <p className="text-sm">{comment.content}</p>
              </div>
            </div>
          ))}

          <div className="flex gap-2 mt-4">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 neuro-card-inset px-4 py-2 rounded-xl bg-transparent outline-none"
            />
            <button
              onClick={() => commentText.trim() && commentMutation.mutate(commentText)}
              disabled={!commentText.trim() || commentMutation.isPending}
              className="neuro-button-accent px-4 py-2 text-white rounded-xl"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}