import React from "react";
import { Dumbbell } from "lucide-react";

export default function GameFitLogo({ size = "default" }) {
  const sizes = {
    small: { icon: "w-4 h-4", text: "text-lg", container: "w-8 h-8" },
    default: { icon: "w-6 h-6", text: "text-2xl", container: "w-12 h-12" },
    large: { icon: "w-8 h-8", text: "text-3xl", container: "w-16 h-16" }
  };

  const currentSize = sizes[size] || sizes.default;

  return (
    <div className="flex items-center gap-3">
      <div 
        className={`neuro-card ${currentSize.container} flex items-center justify-center relative overflow-hidden`}
      >
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            background: 'linear-gradient(135deg, var(--accent-red), var(--accent-yellow))'
          }}
        />
        <Dumbbell className={currentSize.icon} style={{ color: 'var(--accent-red)', position: 'relative', zIndex: 1 }} />
      </div>
      <span className={`${currentSize.text} font-bold text-gradient`}>GameFit</span>
    </div>
  );
}