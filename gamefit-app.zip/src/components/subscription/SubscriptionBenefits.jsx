import React from "react";
import { BarChart3, Palette, Zap, Brain, Shield, Check, X } from "lucide-react";

export default function SubscriptionBenefits({ currentTier }) {
  const benefits = [
    {
      icon: BarChart3,
      title: "Advanced Analytics",
      free: "Basic stats",
      premium: "Detailed reports & insights"
    },
    {
      icon: Palette,
      title: "Avatar Customization",
      free: "Standard items",
      premium: "Exclusive premium items"
    },
    {
      icon: Brain,
      title: "AI Coaching",
      free: "General advice",
      premium: "Specialized programs"
    },
    {
      icon: Zap,
      title: "Feature Access",
      free: "Standard features",
      premium: "Priority early access"
    },
    {
      icon: Shield,
      title: "Experience",
      free: "With ads (future)",
      premium: "100% ad-free"
    }
  ];

  return (
    <div className="neuro-card p-6">
      <h3 className="font-bold text-lg mb-4 text-center">Compare Plans</h3>
      <div className="space-y-4">
        {benefits.map((benefit, index) => {
          const Icon = benefit.icon;
          return (
            <div key={index} className="neuro-card-inset p-4 rounded-xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="neuro-card p-2">
                  <Icon className="w-5 h-5" style={{ color: 'var(--accent-red)' }} />
                </div>
                <h4 className="font-semibold">{benefit.title}</h4>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>
                    Free
                  </p>
                  <p>{benefit.free}</p>
                </div>
                <div>
                  <p className="font-medium mb-1 flex items-center gap-1">
                    <span className="text-gradient">Premium</span>
                  </p>
                  <p className="font-semibold" style={{ color: 'var(--accent-red)' }}>
                    {benefit.premium}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}