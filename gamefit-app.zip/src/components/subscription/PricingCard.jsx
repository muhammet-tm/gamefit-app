import React from "react";
import { Check, Crown, Sparkles } from "lucide-react";

export default function PricingCard({ 
  tier, 
  price, 
  period = "", 
  features, 
  isPremium = false, 
  isCurrent = false,
  onUpgrade 
}) {
  return (
    <div 
      className={`neuro-card p-8 relative ${isPremium ? 'ring-2' : ''}`}
      style={isPremium ? { ringColor: 'var(--accent-yellow)' } : {}}
    >
      {isPremium && (
        <div 
          className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full flex items-center gap-2"
          style={{ background: 'linear-gradient(135deg, var(--accent-red), var(--accent-yellow))' }}
        >
          <Sparkles className="w-3 h-3 text-white" />
          <span className="text-xs font-bold text-white">MOST POPULAR</span>
        </div>
      )}

      <div className="text-center mb-6">
        <div className="flex items-center justify-center gap-2 mb-2">
          {isPremium && <Crown className="w-6 h-6" style={{ color: 'var(--accent-yellow)' }} />}
          <h3 className={`text-2xl font-bold ${isPremium ? 'text-gradient' : ''}`}>
            {tier}
          </h3>
        </div>
        <div className="flex items-baseline justify-center gap-1">
          <span className="text-4xl font-bold">{price}</span>
          {period && (
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              {period}
            </span>
          )}
        </div>
      </div>

      <ul className="space-y-3 mb-6">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-3">
            <Check 
              className="w-5 h-5 flex-shrink-0 mt-0.5" 
              style={{ color: isPremium ? 'var(--accent-yellow)' : '#4ade80' }} 
            />
            <span className="text-sm">{feature}</span>
          </li>
        ))}
      </ul>

      {isCurrent ? (
        <div className="neuro-card-inset py-3 text-center font-semibold">
          Current Plan
        </div>
      ) : onUpgrade ? (
        <button
          onClick={onUpgrade}
          className="neuro-button-accent w-full py-3 text-white font-bold rounded-xl"
        >
          Upgrade to {tier}
        </button>
      ) : null}
    </div>
  );
}